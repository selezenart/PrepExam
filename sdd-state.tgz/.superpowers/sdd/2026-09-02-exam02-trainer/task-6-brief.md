### Task 6: The grading pipeline

**Files:**
- Create: `internal/grader/verdict.go`, `internal/grader/grade.go`
- Test: `internal/grader/grade_test.go`

**Interfaces:**
- Consumes: `catalog.Exercise` (Task 2), `sandbox.Run` (Task 4), `Forbidden`/`DefinesMain`/`objectSymbols` (Task 5).
- Produces: `grader.Status`, `grader.Verdict{Status, Summary, Detail}`, `(Verdict).Passed() bool`, `grader.New() *Grader`, `(*Grader).Grade(ctx, catalog.Exercise, srcPath string) (Verdict, error)`, `grader.CheckToolchain() error`.

- [ ] **Step 1: Write the verdict type**

Create `internal/grader/verdict.go`:

```go
package grader

// Status is the outcome of a grading attempt.
type Status string

const (
	StatusOK           Status = "OK"
	StatusMissingFile  Status = "missing file"
	StatusCompileError Status = "compile error"
	StatusForbidden    Status = "forbidden function"
	StatusUnexpectedMain Status = "unexpected main"
	StatusWrongOutput  Status = "wrong output"
	StatusCrash        Status = "crash"
	StatusTimeout      Status = "timeout"
)

// Verdict is the result of grading one attempt.
type Verdict struct {
	Status  Status
	Summary string // one line, always set
	Detail  string // compiler output or an input/output comparison; may be empty
}

// Passed reports whether the attempt would score points.
func (v Verdict) Passed() bool { return v.Status == StatusOK }
```

- [ ] **Step 2: Write the failing test**

Create `internal/grader/grade_test.go`:

```go
package grader

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"exam02/internal/catalog"
)

func strlenExercise() catalog.Exercise {
	return catalog.Exercise{
		Meta: catalog.Meta{
			Name: "ft_strlen", Level: 1, Kind: catalog.KindFunction,
			ExpectedFile: "ft_strlen.c", AllowedFunctions: nil,
			Prototype: "int ft_strlen(char *str);",
		},
		Reference: "int ft_strlen(char *str){int i=0;while(str[i])i++;return i;}",
		Driver: `#include <stdio.h>
int ft_strlen(char *str);
int main(int argc, char **argv) {
	if (argc < 2) return 1;
	printf("%d\n", ft_strlen(argv[1]));
	return 0;
}`,
		Cases: []catalog.Case{
			{Args: []string{"hello"}},
			{Args: []string{""}},
		},
	}
}

func rot13Exercise() catalog.Exercise {
	return catalog.Exercise{
		Meta: catalog.Meta{
			Name: "rot_13", Level: 1, Kind: catalog.KindProgram,
			ExpectedFile: "rot_13.c", AllowedFunctions: []string{"write"},
		},
		Reference: `#include <unistd.h>
int main(int argc, char **argv) {
	int i = 0;
	if (argc == 2)
		while (argv[1][i]) {
			char c = argv[1][i];
			if (c >= 'a' && c <= 'z') c = (c - 'a' + 13) % 26 + 'a';
			else if (c >= 'A' && c <= 'Z') c = (c - 'A' + 13) % 26 + 'A';
			write(1, &c, 1);
			i++;
		}
	write(1, "\n", 1);
	return 0;
}`,
		Cases: []catalog.Case{{Args: []string{"abc"}}, {Args: []string{}}},
	}
}

// gradeSource writes src as the exercise's expected file and grades it.
func gradeSource(t *testing.T, ex catalog.Exercise, src string) Verdict {
	t.Helper()
	if _, err := exec.LookPath("cc"); err != nil {
		t.Skip("cc not available")
	}
	dir := t.TempDir()
	path := filepath.Join(dir, ex.ExpectedFile)
	if err := os.WriteFile(path, []byte(src), 0o644); err != nil {
		t.Fatal(err)
	}
	v, err := New().Grade(context.Background(), ex, path)
	if err != nil {
		t.Fatalf("Grade() error = %v", err)
	}
	return v
}

func TestGradeAcceptsTheReference(t *testing.T) {
	ex := strlenExercise()
	if v := gradeSource(t, ex, ex.Reference); !v.Passed() {
		t.Errorf("Grade() = %s: %s\n%s", v.Status, v.Summary, v.Detail)
	}
}

func TestGradeRejectsAWrongAnswer(t *testing.T) {
	ex := strlenExercise()
	v := gradeSource(t, ex, "int ft_strlen(char *str){int i=0;while(str[i])i++;return i+1;}")
	if v.Status != StatusWrongOutput {
		t.Errorf("Status = %q, want %q (summary: %s)", v.Status, StatusWrongOutput, v.Summary)
	}
	if v.Detail == "" {
		t.Error("Detail is empty; a wrong answer must show the comparison")
	}
}

func TestGradeRejectsAWarning(t *testing.T) {
	// An unused parameter is -Wextra plus -Werror, which is a real exam failure.
	ex := strlenExercise()
	v := gradeSource(t, ex, "int ft_strlen(char *str){(void)0;return 7;}")
	if v.Status != StatusCompileError {
		t.Errorf("Status = %q, want %q", v.Status, StatusCompileError)
	}
	if v.Detail == "" {
		t.Error("Detail is empty; a compile error must show the compiler output")
	}
}

func TestGradeRejectsAForbiddenFunction(t *testing.T) {
	ex := strlenExercise()
	v := gradeSource(t, ex, `#include <string.h>
int ft_strlen(char *str){return (int)strlen(str);}`)
	if v.Status != StatusForbidden {
		t.Errorf("Status = %q, want %q", v.Status, StatusForbidden)
	}
	if !strings.Contains(v.Summary, "strlen") {
		t.Errorf("Summary = %q, want it to name strlen", v.Summary)
	}
}

func TestGradeRejectsAMainInAFunctionExercise(t *testing.T) {
	ex := strlenExercise()
	v := gradeSource(t, ex, `int ft_strlen(char *str){int i=0;while(str[i])i++;return i;}
int main(void){return 0;}`)
	if v.Status != StatusUnexpectedMain {
		t.Errorf("Status = %q, want %q", v.Status, StatusUnexpectedMain)
	}
}

func TestGradeReportsAMissingFile(t *testing.T) {
	ex := strlenExercise()
	v, err := New().Grade(context.Background(), ex, filepath.Join(t.TempDir(), "absent.c"))
	if err != nil {
		t.Fatalf("Grade() error = %v", err)
	}
	if v.Status != StatusMissingFile {
		t.Errorf("Status = %q, want %q", v.Status, StatusMissingFile)
	}
}

func TestGradeReportsACrash(t *testing.T) {
	ex := strlenExercise()
	v := gradeSource(t, ex, "int ft_strlen(char *str){(void)str;return *(int *)0;}")
	if v.Status != StatusCrash {
		t.Errorf("Status = %q, want %q (summary: %s)", v.Status, StatusCrash, v.Summary)
	}
}

func TestGradeProgramKindAcceptsTheReference(t *testing.T) {
	ex := rot13Exercise()
	if v := gradeSource(t, ex, ex.Reference); !v.Passed() {
		t.Errorf("Grade() = %s: %s\n%s", v.Status, v.Summary, v.Detail)
	}
}

func TestGradeProgramKindRejectsAWrongAnswer(t *testing.T) {
	ex := rot13Exercise()
	// rot 12 instead of rot 13.
	v := gradeSource(t, ex, `#include <unistd.h>
int main(int argc, char **argv) {
	int i = 0;
	if (argc == 2)
		while (argv[1][i]) {
			char c = argv[1][i];
			if (c >= 'a' && c <= 'z') c = (c - 'a' + 12) % 26 + 'a';
			write(1, &c, 1);
			i++;
		}
	write(1, "\n", 1);
	return 0;
}`)
	if v.Status != StatusWrongOutput {
		t.Errorf("Status = %q, want %q", v.Status, StatusWrongOutput)
	}
}
```

- [ ] **Step 3: Run it to verify it fails**

Run: `go test ./internal/grader/ -run TestGrade -v`
Expected: FAIL — `undefined: New`.

- [ ] **Step 4: Write the pipeline**

Create `internal/grader/grade.go`:

```go
package grader

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"exam02/internal/catalog"
	"exam02/internal/sandbox"
)

// compileFlags are the flags the real exam compiles with. A warning is a
// failure, so -Werror is not negotiable.
var compileFlags = []string{"-Wall", "-Wextra", "-Werror"}

// Grader compiles and runs candidate solutions against the reference.
type Grader struct {
	CC string
	NM string
}

// New returns a Grader using the system toolchain.
func New() *Grader { return &Grader{CC: "cc", NM: "nm"} }

// CheckToolchain reports whether the tools the grader needs are present.
func CheckToolchain() error {
	for _, tool := range []string{"cc", "nm"} {
		if _, err := exec.LookPath(tool); err != nil {
			return fmt.Errorf("%s not found in PATH", tool)
		}
	}
	return nil
}

// Grade compiles the candidate's file, checks it for forbidden calls, and runs
// it against the reference solution on every case.
//
// A non-nil error means grading could not be carried out — a missing compiler,
// an unwritable temporary directory. A candidate whose code is wrong is not an
// error: it is a Verdict that did not pass.
func (g *Grader) Grade(ctx context.Context, ex catalog.Exercise, srcPath string) (Verdict, error) {
	source, err := os.ReadFile(srcPath)
	if err != nil {
		return Verdict{
			Status:  StatusMissingFile,
			Summary: fmt.Sprintf("%s not found", ex.ExpectedFile),
		}, nil
	}

	work, err := os.MkdirTemp("", "exam02-grade-")
	if err != nil {
		return Verdict{}, fmt.Errorf("creating work directory: %w", err)
	}
	defer os.RemoveAll(work)

	// Compile the candidate.
	userObj := filepath.Join(work, "user.o")
	if out, err := g.compile(ctx, srcPath, userObj); err != nil {
		return Verdict{
			Status:  StatusCompileError,
			Summary: "your file did not compile with -Wall -Wextra -Werror",
			Detail:  out,
		}, nil
	}

	// Check what it calls before running anything.
	undefined, defined, err := objectSymbols(ctx, userObj)
	if err != nil {
		return Verdict{}, err
	}
	if bad := Forbidden(undefined, ex.AllowedFunctions); len(bad) > 0 {
		return Verdict{
			Status:  StatusForbidden,
			Summary: fmt.Sprintf("forbidden function: %s", strings.Join(bad, ", ")),
			Detail:  allowedSummary(ex),
		}, nil
	}
	if ex.Kind == catalog.KindFunction && DefinesMain(defined) {
		return Verdict{
			Status:  StatusUnexpectedMain,
			Summary: "your file defines main; this exercise expects only the function",
			Detail:  "Submit " + ex.Prototype + " on its own. Comment out any main you used for testing.",
		}, nil
	}

	// Build the reference the same way.
	refPath := filepath.Join(work, "reference.c")
	if err := os.WriteFile(refPath, []byte(ex.Reference), 0o644); err != nil {
		return Verdict{}, err
	}
	refObj := filepath.Join(work, "ref.o")
	if out, err := g.compile(ctx, refPath, refObj); err != nil {
		return Verdict{}, fmt.Errorf("the reference solution for %s did not compile: %s", ex.Name, out)
	}

	userBin, refBin := filepath.Join(work, "user_bin"), filepath.Join(work, "ref_bin")
	var extra []string
	if ex.Kind == catalog.KindFunction {
		driverPath := filepath.Join(work, "driver.c")
		if err := os.WriteFile(driverPath, []byte(ex.Driver), 0o644); err != nil {
			return Verdict{}, err
		}
		driverObj := filepath.Join(work, "driver.o")
		// The driver is ours, not the candidate's, so its own calls are never
		// subject to the allowed-functions check.
		if out, err := g.compile(ctx, driverPath, driverObj); err != nil {
			return Verdict{}, fmt.Errorf("the driver for %s did not compile: %s", ex.Name, out)
		}
		extra = []string{driverObj}
	}
	if out, err := g.link(ctx, append([]string{userObj}, extra...), userBin); err != nil {
		return Verdict{
			Status:  StatusCompileError,
			Summary: "your file compiled but did not link",
			Detail:  out,
		}, nil
	}
	if out, err := g.link(ctx, append([]string{refObj}, extra...), refBin); err != nil {
		return Verdict{}, fmt.Errorf("the reference for %s did not link: %s", ex.Name, out)
	}

	// Compare on every case, stopping at the first difference.
	timeout := time.Duration(ex.Timeout()) * time.Millisecond
	for _, c := range ex.Cases {
		want, err := sandbox.Run(ctx, refBin, c.Args, c.Stdin, timeout)
		if err != nil {
			return Verdict{}, fmt.Errorf("running the reference: %w", err)
		}
		got, err := sandbox.Run(ctx, userBin, c.Args, c.Stdin, timeout)
		if err != nil {
			return Verdict{}, fmt.Errorf("running your program: %w", err)
		}
		if v, ok := compare(ex, c, want, got, timeout); !ok {
			return v, nil
		}
	}
	return Verdict{Status: StatusOK, Summary: "OK"}, nil
}

// compare checks one case. The bool is false when the candidate differs.
func compare(ex catalog.Exercise, c catalog.Case, want, got sandbox.Result, timeout time.Duration) (Verdict, bool) {
	invocation := describeInvocation(ex, c)
	switch {
	case got.TimedOut:
		return Verdict{
			Status:  StatusTimeout,
			Summary: fmt.Sprintf("timed out after %s", timeout),
			Detail:  invocation + "\n\nAn infinite loop is the usual cause.",
		}, false
	case got.Signal != "":
		return Verdict{
			Status:  StatusCrash,
			Summary: crashSummary(got.Signal),
			Detail:  invocation,
		}, false
	case got.Stdout != want.Stdout:
		return Verdict{
			Status:  StatusWrongOutput,
			Summary: "wrong output",
			Detail: fmt.Sprintf("%s\n\nexpected: %s\nactual:   %s",
				invocation, visible(want.Stdout), visible(got.Stdout)),
		}, false
	case got.ExitCode != want.ExitCode:
		return Verdict{
			Status:  StatusWrongOutput,
			Summary: fmt.Sprintf("wrong exit status: expected %d, got %d", want.ExitCode, got.ExitCode),
			Detail:  invocation,
		}, false
	}
	return Verdict{}, true
}

func (g *Grader) compile(ctx context.Context, src, obj string) (string, error) {
	args := append(append([]string{}, compileFlags...), "-c", src, "-o", obj)
	out, err := exec.CommandContext(ctx, g.CC, args...).CombinedOutput()
	return string(out), err
}

func (g *Grader) link(ctx context.Context, objs []string, bin string) (string, error) {
	out, err := exec.CommandContext(ctx, g.CC, append(objs, "-o", bin)...).CombinedOutput()
	return string(out), err
}

func crashSummary(signal string) string {
	switch signal {
	case "SIGSEGV", "SIGBUS":
		return "segfault"
	case "SIGABRT":
		return "aborted"
	case "SIGFPE":
		return "arithmetic error, usually division by zero"
	default:
		return "killed by " + signal
	}
}

// describeInvocation renders the case the way the candidate would run it.
func describeInvocation(ex catalog.Exercise, c catalog.Case) string {
	parts := []string{"$> ./" + ex.Name}
	for _, a := range c.Args {
		parts = append(parts, quote(a))
	}
	line := strings.Join(parts, " ")
	if c.Stdin != "" {
		line += "\nstdin: " + visible(c.Stdin)
	}
	return line
}

func quote(s string) string {
	if s == "" || strings.ContainsAny(s, " \t\n\"") {
		return fmt.Sprintf("%q", s)
	}
	return s
}

// visible renders output so that trailing whitespace and missing newlines are
// not invisible in the diff, the way cat -e is used in the subjects.
func visible(s string) string {
	s = strings.ReplaceAll(s, "\n", "$\n")
	if s == "" {
		return "(nothing)"
	}
	return s
}

func allowedSummary(ex catalog.Exercise) string {
	if len(ex.AllowedFunctions) == 0 {
		return "This exercise allows no library functions at all."
	}
	return "This exercise allows only: " + strings.Join(ex.AllowedFunctions, ", ")
}
```

- [ ] **Step 5: Run the tests to verify they pass**

Run: `go test ./internal/grader/ -v`
Expected: PASS, every test.

- [ ] **Step 6: Commit**

```bash
git add internal/grader/
git commit -m "feat(grader): compile, check symbols, and diff against the reference

The reference solution is the oracle: candidate and reference are built
with identical flags, linked against the same driver, and run on the same
inputs. A difference in stdout or exit status fails the attempt. This is
why no expected outputs have to be written by hand.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

