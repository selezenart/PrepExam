### Task 14: Release pipeline and documentation

**Files:**
- Create: `Makefile`, `README.md`

**Interfaces:**
- Consumes: the built binary from Task 13.
- Produces: `dist/exam02_<os>_<arch>` for four platforms, plus `dist/SHA256SUMS`.

- [ ] **Step 1: Write the Makefile**

```makefile
BINARY  := exam02
VERSION ?= $(shell git describe --tags --always --dirty 2>/dev/null || echo dev)
LDFLAGS := -s -w -X main.version=$(VERSION)

PLATFORMS := darwin/arm64 darwin/amd64 linux/amd64 linux/arm64

.PHONY: all build test vet dist clean

all: test build

build:
	go build -ldflags '$(LDFLAGS)' -o $(BINARY) ./cmd/exam02

test:
	go test ./...

vet:
	go vet ./...

# Cross-compiles every supported platform. cgo stays off so the binaries are
# static and the macOS builds need no Mac to produce.
dist: test
	@mkdir -p dist
	@for platform in $(PLATFORMS); do \
		os=$${platform%/*}; arch=$${platform#*/}; \
		echo "building $$os/$$arch"; \
		CGO_ENABLED=0 GOOS=$$os GOARCH=$$arch \
			go build -ldflags '$(LDFLAGS)' -o dist/$(BINARY)_$${os}_$${arch} ./cmd/exam02 || exit 1; \
	done
	@cd dist && shasum -a 256 $(BINARY)_* > SHA256SUMS 2>/dev/null || sha256sum $(BINARY)_* > SHA256SUMS
	@ls -lh dist/

clean:
	rm -rf dist $(BINARY)
```

- [ ] **Step 2: Build every platform**

```bash
make dist
file dist/exam02_darwin_arm64
```
Expected: four binaries and a `SHA256SUMS`. `file` reports the darwin build as a Mach-O arm64 executable, proving the cross-compile worked from Linux.

- [ ] **Step 3: Write the README**

Create `README.md`:

````markdown
# exam02

A terminal trainer for the 42 Common Core Exam Rank 02.

It shows you a subject, gives you a workspace, and grades what you write —
including the allowed-functions check that the real Moulinette enforces and
that most informal practice setups skip.

## Install

Download the binary for your platform, make it executable, and put it on your
PATH:

```bash
chmod +x exam02_darwin_arm64
mv exam02_darwin_arm64 /usr/local/bin/exam02
```

The macOS builds are unsigned, so Gatekeeper quarantines them on download.
Clear it once:

```bash
xattr -d com.apple.quarantine /usr/local/bin/exam02
```

You need a C toolchain — `cc` and `nm`. macOS: `xcode-select --install`.
Debian or Ubuntu: `sudo apt install build-essential`.

## Use

```bash
mkdir practice && cd practice
exam02
```

`rendu/` is created in the current directory, exactly as in the real exam.

- **Exam** — three hours, one exercise drawn from each of the four levels.
  25 points each, 100 to pass, so passing means clearing every level. Failing
  an exercise draws another from the same level: it costs you time, not points.
- **Practice** — any exercise, no clock, unlimited attempts, and the reference
  solution available with `r` when you want it.

Keys: `g` grade, `e` edit in `$EDITOR` (`vim` by default), `r` reveal the
solution in practice, `w` drill your weakest exercise, `q` back.

## How grading works

Your file is compiled with `cc -Wall -Wextra -Werror`, so a warning fails you,
as it does in the real exam. Then `nm` is used to check you have not called a
function the subject forbids. Then your code and the reference solution are run
on the same inputs and their output compared.

The reference solutions are the oracle, which is why no expected outputs are
written by hand — and it means a bug shared by your code and the reference will
not be caught. Treat this as practice, not as the Moulinette.

## Build

```bash
make test     # run the suite
make build    # build for this machine
make dist     # cross-compile all four platforms
```

The suite's most important test grades every reference solution against its own
grader. If a driver or a case file is wrong, that test fails.

## Content status

Level 1 is complete and gradable. Levels 2 to 4 ship with their subjects and
reference solutions, and become gradable as their drivers and case files land.

## Credit

Exercise subjects, the Spanish explainers, and the reference solutions come
from [alexhiguera/Exam_Rank_02_42_School](https://github.com/alexhiguera/Exam_Rank_02_42_School),
MIT licensed, Copyright (c) 2026 Alex Higuera. The upstream licence is kept at
`third_party/exam_rank_02/LICENSE`.

This is a practice tool. The real exam runs in a closed environment under the
Moulinette, and its rules are the ones that count.
````

- [ ] **Step 4: Verify the whole thing once more**

```bash
go vet ./...
go test ./...
make dist
```
Expected: clean vet, green tests, four binaries.

- [ ] **Step 5: Commit**

```bash
git add Makefile README.md
git commit -m "build: cross-compile release targets and document the tool

CGO stays off so all four binaries are static and the macOS builds need no
Mac to produce. The README says plainly that the reference solutions are
the grading oracle, so a bug shared with the reference goes uncaught.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

