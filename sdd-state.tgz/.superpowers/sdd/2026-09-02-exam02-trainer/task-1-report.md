# Task 1: Module skeleton and subject parser - Report

## Status
Successfully completed. All tests pass. Module initialized and parser implemented.

## TDD Evidence

### Step 1: Initialize the module
```bash
$ go mod init exam02
$ go mod edit -go=1.24
```
Result: `go.mod` created with `go 1.24` directive.

### Step 2-3: Write and run the failing test (RED phase)

Command:
```bash
go test ./internal/catalog/ -run TestParseSubject -v
```

Output (expected failure):
```
# exam02/internal/catalog [exam02/internal/catalog.test]
internal/catalog/subject_test.go:18:14: undefined: ParseSubject
internal/catalog/subject_test.go:49:16: undefined: ParseSubject
internal/catalog/subject_test.go:62:14: undefined: ParseSubject
internal/catalog/subject_test.go:76:14: undefined: ParseSubject
internal/catalog/subject_test.go:86:15: undefined: ParseSubject
FAIL	exam02/internal/catalog [build failed]
FAIL
```

**Why this failure was expected:** The test file references `ParseSubject()` function which does not exist yet. This is the correct RED phase of TDD - the test code compiles but the function is undefined, causing the build to fail.

### Step 4-5: Write implementation and run passing tests (GREEN phase)

Implementation written to `internal/catalog/subject.go` containing:
- `SubjectMeta` struct with Name, ExpectedFile, and AllowedFunctions fields
- `ParseSubject(md string)` function that parses upstream subject headers
- Helper functions: `splitField()`, `sourceFile()`, `parseAllowedFunctions()`

Command:
```bash
go test ./internal/catalog/ -v
```

Output (all tests passing):
```
=== RUN   TestParseSubjectReadsHeaderFields
--- PASS: TestParseSubjectReadsHeaderFields (0.00s)
=== RUN   TestParseSubjectAllowedFunctions
=== RUN   TestParseSubjectAllowedFunctions/empty_means_none
=== RUN   TestParseSubjectAllowedFunctions/literal_None
=== RUN   TestParseSubjectAllowedFunctions/literal_dash
=== RUN   TestParseSubjectAllowedFunctions/single
=== RUN   TestParseSubjectAllowedFunctions/list
=== RUN   TestParseSubjectAllowedFunctions/ragged_spacing
--- PASS: TestParseSubjectAllowedFunctions (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/empty_means_none (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/literal_None (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/literal_dash (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/single (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/list (0.00s)
    --- PASS: TestParseSubjectAllowedFunctions/ragged_spacing (0.00s)
=== RUN   TestParseSubjectMultipleExpectedFilesTakesTheC
--- PASS: TestParseSubjectMultipleExpectedFilesTakesTheC (0.00s)
=== RUN   TestParseSubjectGlobExpectedFilesIsUnresolved
--- PASS: TestParseSubjectGlobExpectedFilesIsUnresolved (0.00s)
=== RUN   TestParseSubjectWithoutAssignmentNameIsAnError
--- PASS: TestParseSubjectWithoutAssignmentNameIsAnError (0.00s)
PASS
ok  	exam02/internal/catalog	0.002s
```

**All 9 test cases pass:**
- TestParseSubjectReadsHeaderFields (basic parsing)
- TestParseSubjectAllowedFunctions with 6 subtests (empty, None, dash, single, list, ragged spacing)
- TestParseSubjectMultipleExpectedFilesTakesTheC (prefers .c file)
- TestParseSubjectGlobExpectedFilesIsUnresolved (returns empty for globs)
- TestParseSubjectWithoutAssignmentNameIsAnError (error handling)

### Step 6: Commit

Commit details:
- Short SHA: `2cefb7b`
- Branch: `feat/trainer`
- Message: "feat(catalog): parse upstream exercise subjects"
- Files created:
  - `go.mod` (module initialization with go 1.24)
  - `internal/catalog/subject.go` (implementation)
  - `internal/catalog/subject_test.go` (tests)

## Implementation Notes

The parser correctly handles:
1. **Five spelling variations for empty allowed functions:** empty string, "None" (case-insensitive), and "-"
2. **Multiple expected files:** Prefers `.c` files over headers (which are provided)
3. **Glob patterns:** Returns empty ExpectedFile for `*.c, *.h` patterns (to be resolved by meta.yaml)
4. **Error handling:** Returns error only when assignment name is missing (not for missing expected file)
5. **Whitespace handling:** Trims surrounding spaces from field values and function lists

All code exactly matches the brief specification. No dependencies added (Task 1 requires none).
