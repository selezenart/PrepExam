### Task 9: Exam state machine

Pure logic, no compiler and no terminal, so every rule is testable directly.

**Files:**
- Create: `internal/session/exam.go`
- Test: `internal/session/exam_test.go`

**Interfaces:**
- Consumes: `store.Config` (Task 8), `catalog.Catalog` (Task 2).
- Produces: `session.Exam`, `session.NewExam(cfg store.Config, pools map[int][]string, rng *rand.Rand, now time.Time) *Exam`, `(*Exam).Current() string`, `(*Exam).Level() int`, `(*Exam).Record(passed bool, now time.Time)`, `(*Exam).Points() int`, `(*Exam).Remaining(now time.Time) time.Duration`, `(*Exam).Over(now time.Time) bool`, `(*Exam).Passed() bool`, `(*Exam).Attempts() []session.Attempt`.

- [ ] **Step 1: Write the failing test**

Create `internal/session/exam_test.go`:

```go
package session

import (
	"math/rand"
	"testing"
	"time"

	"exam02/internal/store"
)

func testPools() map[int][]string {
	return map[int][]string{
		1: {"ft_strlen", "rot_13"},
		2: {"ft_atoi"},
		3: {"epur_str"},
		4: {"ft_split"},
	}
}

func newTestExam(t *testing.T, start time.Time) *Exam {
	t.Helper()
	e, err := NewExam(store.DefaultConfig(), testPools(), rand.New(rand.NewSource(1)), start)
	if err != nil {
		t.Fatalf("NewExam() error = %v", err)
	}
	return e
}

func TestNewExamStartsAtLevelOne(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	if e.Level() != 1 {
		t.Errorf("Level() = %d, want 1", e.Level())
	}
	if e.Points() != 0 {
		t.Errorf("Points() = %d, want 0", e.Points())
	}
	if got := e.Current(); got != "ft_strlen" && got != "rot_13" {
		t.Errorf("Current() = %q, want one of the level 1 pool", got)
	}
}

func TestPassingAdvancesALevelAndScores(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	e.Record(true, start.Add(time.Minute))
	if e.Level() != 2 {
		t.Errorf("Level() = %d, want 2", e.Level())
	}
	if e.Points() != 25 {
		t.Errorf("Points() = %d, want 25", e.Points())
	}
	if e.Current() != "ft_atoi" {
		t.Errorf("Current() = %q, want ft_atoi", e.Current())
	}
}

func TestFailingRedrawsFromTheSameLevel(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	e.Record(false, start.Add(time.Minute))
	if e.Level() != 1 {
		t.Errorf("Level() = %d, want 1", e.Level())
	}
	if e.Points() != 0 {
		t.Errorf("Points() = %d, want 0", e.Points())
	}
	if e.Over(start.Add(2 * time.Minute)) {
		t.Error("Over() = true; a failed attempt must not end the exam")
	}
}

func TestClearingAllFourLevelsPasses(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	for i := 0; i < 4; i++ {
		e.Record(true, start.Add(time.Duration(i)*time.Minute))
	}
	if e.Points() != 100 {
		t.Errorf("Points() = %d, want 100", e.Points())
	}
	if !e.Passed() {
		t.Error("Passed() = false, want true at 100 points")
	}
	if !e.Over(start.Add(5 * time.Minute)) {
		t.Error("Over() = false, want true after the last level")
	}
	if e.Current() != "" {
		t.Errorf("Current() = %q, want empty once the exam is over", e.Current())
	}
}

func TestThreeOfFourLevelsFails(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	for i := 0; i < 3; i++ {
		e.Record(true, start.Add(time.Duration(i)*time.Minute))
	}
	if e.Points() != 75 {
		t.Errorf("Points() = %d, want 75", e.Points())
	}
	if e.Passed() {
		t.Error("Passed() = true at 75 points, want false: the pass mark is 100")
	}
}

func TestTimeExpiryEndsTheExam(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	if e.Over(start.Add(2 * time.Hour)) {
		t.Error("Over() = true after 2h, want false")
	}
	if !e.Over(start.Add(3 * time.Hour)) {
		t.Error("Over() = false after 3h, want true")
	}
	if got := e.Remaining(start.Add(4 * time.Hour)); got != 0 {
		t.Errorf("Remaining() = %v past the deadline, want 0", got)
	}
}

func TestRemainingCountsDown(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	if got := e.Remaining(start.Add(time.Hour)); got != 2*time.Hour {
		t.Errorf("Remaining() = %v, want 2h", got)
	}
}

func TestAttemptsAreRecordedInOrder(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	first := e.Current()
	e.Record(false, start.Add(time.Minute))
	e.Record(true, start.Add(2*time.Minute))

	got := e.Attempts()
	if len(got) != 2 {
		t.Fatalf("Attempts() = %d, want 2", len(got))
	}
	if got[0].Exercise != first || got[0].Passed {
		t.Errorf("first attempt = %+v, want %q failed", got[0], first)
	}
	if !got[1].Passed {
		t.Errorf("second attempt = %+v, want passed", got[1])
	}
}

func TestRecordAfterTheExamIsOverIsIgnored(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	for i := 0; i < 4; i++ {
		e.Record(true, start.Add(time.Duration(i)*time.Minute))
	}
	e.Record(true, start.Add(10*time.Minute))
	if e.Points() != 100 {
		t.Errorf("Points() = %d, want it capped at 100", e.Points())
	}
}

func TestNewExamNeedsEveryLevelStocked(t *testing.T) {
	pools := testPools()
	delete(pools, 3)
	if _, err := NewExam(store.DefaultConfig(), pools, rand.New(rand.NewSource(1)), time.Now()); err == nil {
		t.Fatal("NewExam() error = nil, want an error when a level has no exercises")
	}
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/session/ -v`
Expected: FAIL — `undefined: NewExam`.

- [ ] **Step 3: Write the state machine**

Create `internal/session/exam.go`:

```go
// Package session holds the rules of an exam run: which exercise is current,
// what a pass or a fail does, and when the run is over. It touches neither the
// compiler nor the terminal, so every rule here is testable on its own.
package session

import (
	"fmt"
	"math/rand"
	"time"

	"exam02/internal/store"
)

// levels is how many levels an exam covers. One exercise is drawn from each,
// so four passes at 25 points each is the 100-point pass mark.
const levels = 4

// Attempt is one graded submission during an exam.
type Attempt struct {
	Exercise string    `json:"exercise"`
	Level    int       `json:"level"`
	Passed   bool      `json:"passed"`
	At       time.Time `json:"at"`
}

// Exam is one run: four exercises, one drawn from each level, against a clock.
type Exam struct {
	StartedAt time.Time     `json:"started_at"`
	Duration  time.Duration `json:"duration"`
	PerLevel  int           `json:"per_level"`
	PassMark  int           `json:"pass_mark"`

	CurrentLevel    int       `json:"current_level"`
	CurrentExercise string    `json:"current_exercise"`
	Cleared         int       `json:"cleared"`
	History         []Attempt `json:"history"`

	pools map[int][]string
	rng   *rand.Rand
}

// NewExam starts a run, drawing the first exercise from the Level 1 pool.
//
// pools maps a level to the names of its exercises. Every level must have at
// least one: an exam that cannot draw an exercise for a level could never be
// passed, and failing at the start says so more clearly than failing later.
func NewExam(cfg store.Config, pools map[int][]string, rng *rand.Rand, now time.Time) (*Exam, error) {
	for level := 1; level <= levels; level++ {
		if len(pools[level]) == 0 {
			return nil, fmt.Errorf("level %d has no exercises to draw from", level)
		}
	}
	e := &Exam{
		StartedAt:    now,
		Duration:     cfg.ExamDuration,
		PerLevel:     cfg.PointsPerExercise,
		PassMark:     cfg.PassMark,
		CurrentLevel: 1,
		pools:        pools,
		rng:          rng,
	}
	e.draw()
	return e, nil
}

// Attach restores the pools and randomness after an exam has been decoded from
// saved state, which cannot carry either.
func (e *Exam) Attach(pools map[int][]string, rng *rand.Rand) {
	e.pools, e.rng = pools, rng
}

// draw picks a fresh exercise from the current level's pool, avoiding the one
// just attempted where the pool is big enough to allow it.
func (e *Exam) draw() {
	pool := e.pools[e.CurrentLevel]
	if len(pool) == 0 {
		e.CurrentExercise = ""
		return
	}
	if len(pool) == 1 {
		e.CurrentExercise = pool[0]
		return
	}
	for {
		candidate := pool[e.rng.Intn(len(pool))]
		if candidate != e.CurrentExercise {
			e.CurrentExercise = candidate
			return
		}
	}
}

// Record notes the outcome of grading the current exercise. Passing clears the
// level and draws from the next one; failing draws again from the same level,
// which costs time rather than points.
func (e *Exam) Record(passed bool, now time.Time) {
	if e.Over(now) {
		return
	}
	e.History = append(e.History, Attempt{
		Exercise: e.CurrentExercise,
		Level:    e.CurrentLevel,
		Passed:   passed,
		At:       now,
	})
	if !passed {
		e.draw()
		return
	}
	e.Cleared++
	if e.Cleared >= levels {
		e.CurrentExercise = ""
		return
	}
	e.CurrentLevel++
	e.draw()
}

// Current is the exercise being attempted, or "" once the exam is over.
func (e *Exam) Current() string { return e.CurrentExercise }

// Level is the level being attempted.
func (e *Exam) Level() int { return e.CurrentLevel }

// Points is the score so far.
func (e *Exam) Points() int { return e.Cleared * e.PerLevel }

// Passed reports whether the score has reached the pass mark.
func (e *Exam) Passed() bool { return e.Points() >= e.PassMark }

// Remaining is the time left, floored at zero.
func (e *Exam) Remaining(now time.Time) time.Duration {
	left := e.Duration - now.Sub(e.StartedAt)
	if left < 0 {
		return 0
	}
	return left
}

// Over reports whether the run has finished, by the clock or by clearing every
// level.
func (e *Exam) Over(now time.Time) bool {
	return e.Cleared >= levels || e.Remaining(now) == 0
}

// Attempts is the history of graded submissions, oldest first.
func (e *Exam) Attempts() []Attempt { return e.History }
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `go test ./internal/session/ -v`
Expected: PASS.

- [ ] **Step 5: Write the failing resume test**

The spec requires an in-progress exam to survive a crash or an accidental
quit. A three hour run is far too much to lose to a stray Ctrl-C.

Append to `internal/session/exam_test.go`:

```go
func TestExamSurvivesASaveAndReload(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	e.Record(true, start.Add(time.Minute))    // clears level 1
	e.Record(false, start.Add(2*time.Minute)) // fails once at level 2

	encoded, err := Encode(e)
	if err != nil {
		t.Fatalf("Encode() error = %v", err)
	}
	restored, err := Decode(encoded, testPools(), rand.New(rand.NewSource(2)))
	if err != nil {
		t.Fatalf("Decode() error = %v", err)
	}
	if restored.Level() != 2 {
		t.Errorf("Level() = %d, want 2", restored.Level())
	}
	if restored.Points() != 25 {
		t.Errorf("Points() = %d, want 25", restored.Points())
	}
	if len(restored.Attempts()) != 2 {
		t.Errorf("Attempts() = %d, want 2", len(restored.Attempts()))
	}
	if restored.Current() == "" {
		t.Error("Current() is empty; the restored exam has nothing to work on")
	}
}

func TestRestoredExamKeepsCountingFromItsOriginalStart(t *testing.T) {
	// The clock must not restart on resume, or quitting and reopening would
	// be a way to buy unlimited time.
	start := time.Now().Add(-time.Hour)
	e := newTestExam(t, start)
	encoded, err := Encode(e)
	if err != nil {
		t.Fatalf("Encode() error = %v", err)
	}
	restored, err := Decode(encoded, testPools(), rand.New(rand.NewSource(2)))
	if err != nil {
		t.Fatalf("Decode() error = %v", err)
	}
	if got := restored.Remaining(time.Now()); got > 2*time.Hour {
		t.Errorf("Remaining() = %v, want about 2h: the clock must not restart", got)
	}
}

func TestDecodeOfAFinishedExamIsNotResumable(t *testing.T) {
	start := time.Now()
	e := newTestExam(t, start)
	for i := 0; i < 4; i++ {
		e.Record(true, start.Add(time.Duration(i)*time.Minute))
	}
	encoded, err := Encode(e)
	if err != nil {
		t.Fatalf("Encode() error = %v", err)
	}
	restored, err := Decode(encoded, testPools(), rand.New(rand.NewSource(2)))
	if err != nil {
		t.Fatalf("Decode() error = %v", err)
	}
	if !restored.Over(time.Now()) {
		t.Error("Over() = false; a finished exam must not come back resumable")
	}
}
```

- [ ] **Step 6: Run it to verify it fails**

Run: `go test ./internal/session/ -run 'TestExamSurvives|TestRestored|TestDecodeOf' -v`
Expected: FAIL — `undefined: Encode`.

- [ ] **Step 7: Write Encode and Decode**

Append to `internal/session/exam.go`:

```go
// Encode serialises an exam for storage. The draw pools and the random source
// are deliberately left out: pools are rebuilt from the catalog on load, so a
// saved exam cannot pin the application to a stale copy of the exercise list.
func Encode(e *Exam) (json.RawMessage, error) {
	raw, err := json.Marshal(e)
	if err != nil {
		return nil, fmt.Errorf("encoding the exam: %w", err)
	}
	return raw, nil
}

// Decode restores a saved exam and reattaches the pools and randomness that
// could not be serialised.
//
// The start time is restored as it was, so the clock carries on from where it
// stopped. Restarting it would turn quitting and reopening into a way to buy
// unlimited time.
func Decode(raw json.RawMessage, pools map[int][]string, rng *rand.Rand) (*Exam, error) {
	var e Exam
	if err := json.Unmarshal(raw, &e); err != nil {
		return nil, fmt.Errorf("decoding the exam: %w", err)
	}
	if e.CurrentLevel < 1 || e.CurrentLevel > levels {
		return nil, fmt.Errorf("saved exam has an impossible level %d", e.CurrentLevel)
	}
	e.Attach(pools, rng)
	return &e, nil
}
```

Add `"encoding/json"` to the file's imports.

- [ ] **Step 8: Run the tests to verify they pass**

Run: `go test ./internal/session/ -v`
Expected: PASS, every test.

- [ ] **Step 9: Commit**

```bash
git add internal/session/
git commit -m "feat(session): exam rules as a testable state machine

Four exercises, one drawn per level, 25 points each against a 100-point
pass mark and a three hour clock. A failure redraws from the same level,
so it costs time rather than points. No compiler and no terminal here,
which is what makes every rule directly testable.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

