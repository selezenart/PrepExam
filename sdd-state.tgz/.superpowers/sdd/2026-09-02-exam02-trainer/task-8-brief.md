### Task 8: Configuration and persisted state

**Files:**
- Create: `internal/store/config.go`, `internal/store/state.go`
- Test: `internal/store/state_test.go`

**Interfaces:**
- Consumes: nothing.
- Produces: `store.Config{ExamDuration time.Duration; PointsPerExercise, PassMark int}`, `store.DefaultConfig()`, `store.LoadConfig(dir string) (Config, error)`, `store.Stats{Attempts, Passes int; LastStatus string; LastAt time.Time}`, `store.State`, `store.Load(dir string) (*State, error)`, `(*State).Save(dir string) error`, `(*State).Record(name, status string, passed bool)`, `(*State).Weakest([]string) string`, `store.Dir() (string, error)`.

- [ ] **Step 1: Write the failing test**

Create `internal/store/state_test.go`:

```go
package store

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLoadFromAnEmptyDirectoryGivesEmptyState(t *testing.T) {
	s, err := Load(t.TempDir())
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if len(s.Exercises) != 0 {
		t.Errorf("Exercises = %v, want empty", s.Exercises)
	}
	if s.Exam != nil {
		t.Errorf("Exam = %v, want nil", s.Exam)
	}
}

func TestRecordAndRoundTrip(t *testing.T) {
	dir := t.TempDir()
	s, err := Load(dir)
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	s.Record("ft_strlen", "OK", true)
	s.Record("rot_13", "wrong output", false)
	s.Record("rot_13", "wrong output", false)
	if err := s.Save(dir); err != nil {
		t.Fatalf("Save() error = %v", err)
	}

	again, err := Load(dir)
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if got := again.Exercises["ft_strlen"]; got.Attempts != 1 || got.Passes != 1 {
		t.Errorf("ft_strlen = %+v, want 1 attempt 1 pass", got)
	}
	if got := again.Exercises["rot_13"]; got.Attempts != 2 || got.Passes != 0 {
		t.Errorf("rot_13 = %+v, want 2 attempts 0 passes", got)
	}
	if again.Exercises["rot_13"].LastStatus != "wrong output" {
		t.Errorf("LastStatus = %q, want %q", again.Exercises["rot_13"].LastStatus, "wrong output")
	}
}

func TestSaveIsAtomic(t *testing.T) {
	dir := t.TempDir()
	s, _ := Load(dir)
	s.Record("ft_strlen", "OK", true)
	if err := s.Save(dir); err != nil {
		t.Fatalf("Save() error = %v", err)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	// A crash mid-save must not leave a partial file behind under a name the
	// next Load would read.
	for _, e := range entries {
		if e.Name() != stateFile {
			t.Errorf("Save() left %q behind, want only %q", e.Name(), stateFile)
		}
	}
}

func TestLoadIgnoresCorruptState(t *testing.T) {
	// Losing statistics is annoying; refusing to start is worse.
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, stateFile), []byte("{ not json"), 0o644); err != nil {
		t.Fatal(err)
	}
	s, err := Load(dir)
	if err != nil {
		t.Fatalf("Load() error = %v, want it to recover", err)
	}
	if len(s.Exercises) != 0 {
		t.Errorf("Exercises = %v, want empty", s.Exercises)
	}
}

func TestWeakestPicksMostFailedThenLeastRecent(t *testing.T) {
	s, _ := Load(t.TempDir())
	pool := []string{"a", "b", "c"}

	// Never attempted beats attempted: you cannot be weaker than untested.
	s.Exercises["a"] = &Stats{Attempts: 5, Passes: 1, LastAt: time.Now()}
	if got := s.Weakest(pool); got != "b" && got != "c" {
		t.Errorf("Weakest() = %q, want an unattempted exercise", got)
	}

	old := time.Now().Add(-72 * time.Hour)
	s.Exercises["b"] = &Stats{Attempts: 3, Passes: 3, LastAt: time.Now()}
	s.Exercises["c"] = &Stats{Attempts: 4, Passes: 0, LastAt: old}
	if got := s.Weakest(pool); got != "c" {
		t.Errorf("Weakest() = %q, want c: it has the most failures", got)
	}
}

func TestDefaultConfigMatchesTheRealExam(t *testing.T) {
	c := DefaultConfig()
	if c.ExamDuration != 3*time.Hour {
		t.Errorf("ExamDuration = %v, want 3h", c.ExamDuration)
	}
	if c.PointsPerExercise != 25 {
		t.Errorf("PointsPerExercise = %d, want 25", c.PointsPerExercise)
	}
	if c.PassMark != 100 {
		t.Errorf("PassMark = %d, want 100", c.PassMark)
	}
}

func TestLoadConfigFallsBackToDefaults(t *testing.T) {
	c, err := LoadConfig(t.TempDir())
	if err != nil {
		t.Fatalf("LoadConfig() error = %v", err)
	}
	if c != DefaultConfig() {
		t.Errorf("LoadConfig() = %+v, want the defaults", c)
	}
}

func TestLoadConfigReadsOverrides(t *testing.T) {
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, configFile),
		[]byte("exam_duration: 90m\npoints_per_exercise: 25\npass_mark: 50\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	c, err := LoadConfig(dir)
	if err != nil {
		t.Fatalf("LoadConfig() error = %v", err)
	}
	if c.ExamDuration != 90*time.Minute {
		t.Errorf("ExamDuration = %v, want 90m", c.ExamDuration)
	}
	if c.PassMark != 50 {
		t.Errorf("PassMark = %d, want 50", c.PassMark)
	}
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/store/ -v`
Expected: FAIL — `undefined: Load`.

- [ ] **Step 3: Write the config**

Create `internal/store/config.go`:

```go
// Package store holds the user's configuration and their saved progress.
package store

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"gopkg.in/yaml.v3"
)

const configFile = "config.yaml"

// Config holds the exam rules. They are configurable so a variant ruleset can
// be tried without a rebuild, but the defaults are the real exam's.
type Config struct {
	ExamDuration      time.Duration
	PointsPerExercise int
	PassMark          int
}

// DefaultConfig returns the real Exam Rank 02 rules: three hours, 25 points
// per exercise, 100 points to pass, which means clearing all four levels.
func DefaultConfig() Config {
	return Config{
		ExamDuration:      3 * time.Hour,
		PointsPerExercise: 25,
		PassMark:          100,
	}
}

// configFileFormat is the on-disk shape, kept separate so the duration can be
// written the way a person would type it.
type configFileFormat struct {
	ExamDuration      string `yaml:"exam_duration"`
	PointsPerExercise int    `yaml:"points_per_exercise"`
	PassMark          int    `yaml:"pass_mark"`
}

// LoadConfig reads config.yaml from dir, falling back to the defaults when it
// is absent. A malformed file is an error rather than a silent fallback:
// having quietly ignored the rules someone wrote would be worse than saying so.
func LoadConfig(dir string) (Config, error) {
	c := DefaultConfig()
	raw, err := os.ReadFile(filepath.Join(dir, configFile))
	if os.IsNotExist(err) {
		return c, nil
	}
	if err != nil {
		return c, fmt.Errorf("reading %s: %w", configFile, err)
	}
	var f configFileFormat
	if err := yaml.Unmarshal(raw, &f); err != nil {
		return c, fmt.Errorf("parsing %s: %w", configFile, err)
	}
	if f.ExamDuration != "" {
		d, err := time.ParseDuration(f.ExamDuration)
		if err != nil {
			return c, fmt.Errorf("exam_duration %q: %w", f.ExamDuration, err)
		}
		c.ExamDuration = d
	}
	if f.PointsPerExercise > 0 {
		c.PointsPerExercise = f.PointsPerExercise
	}
	if f.PassMark > 0 {
		c.PassMark = f.PassMark
	}
	return c, nil
}
```

- [ ] **Step 4: Write the state**

Create `internal/store/state.go`:

```go
package store

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

const stateFile = "state.json"

// Stats is what is remembered about one exercise.
type Stats struct {
	Attempts   int       `json:"attempts"`
	Passes     int       `json:"passes"`
	LastStatus string    `json:"last_status"`
	LastAt     time.Time `json:"last_at"`
}

// Failures is how many attempts did not pass.
func (s Stats) Failures() int { return s.Attempts - s.Passes }

// State is the persisted progress. ExamJSON carries an in-progress exam as
// opaque JSON so that store does not depend on the session package and the
// two can change independently.
type State struct {
	Exercises map[string]*Stats `json:"exercises"`
	Exam      json.RawMessage   `json:"exam,omitempty"`
}

// Dir returns the per-user directory holding config and state.
func Dir() (string, error) {
	base, err := os.UserConfigDir()
	if err != nil {
		return "", fmt.Errorf("locating the user config directory: %w", err)
	}
	dir := filepath.Join(base, "exam02")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", fmt.Errorf("creating %s: %w", dir, err)
	}
	return dir, nil
}

// Load reads the saved state from dir. A missing or unreadable file gives
// empty state rather than an error: losing statistics is a nuisance, but
// refusing to start the application over them would be worse.
func Load(dir string) (*State, error) {
	s := &State{Exercises: map[string]*Stats{}}
	raw, err := os.ReadFile(filepath.Join(dir, stateFile))
	if err != nil {
		return s, nil
	}
	if err := json.Unmarshal(raw, s); err != nil {
		return &State{Exercises: map[string]*Stats{}}, nil
	}
	if s.Exercises == nil {
		s.Exercises = map[string]*Stats{}
	}
	return s, nil
}

// Save writes the state to dir atomically: a crash partway through must not
// leave a truncated file where the next Load would find it.
func (s *State) Save(dir string) error {
	raw, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return fmt.Errorf("encoding state: %w", err)
	}
	tmp, err := os.CreateTemp(dir, ".state-*.tmp")
	if err != nil {
		return fmt.Errorf("creating a temporary file: %w", err)
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName) // no-op once the rename has succeeded

	if _, err := tmp.Write(raw); err != nil {
		tmp.Close()
		return fmt.Errorf("writing state: %w", err)
	}
	if err := tmp.Close(); err != nil {
		return fmt.Errorf("closing state: %w", err)
	}
	if err := os.Rename(tmpName, filepath.Join(dir, stateFile)); err != nil {
		return fmt.Errorf("replacing state: %w", err)
	}
	return nil
}

// Record notes one grading attempt.
func (s *State) Record(exercise, status string, passed bool) {
	st, ok := s.Exercises[exercise]
	if !ok {
		st = &Stats{}
		s.Exercises[exercise] = st
	}
	st.Attempts++
	if passed {
		st.Passes++
	}
	st.LastStatus = status
	st.LastAt = time.Now()
}

// Weakest picks the exercise from pool most worth practising: the one never
// attempted, else the one with the most failures, ties going to whichever was
// attempted longest ago. Returns "" for an empty pool.
func (s *State) Weakest(pool []string) string {
	var best string
	var bestFailures int
	var bestAt time.Time

	for _, name := range pool {
		st, seen := s.Exercises[name]
		if !seen || st.Attempts == 0 {
			return name
		}
		failures := st.Failures()
		if best == "" || failures > bestFailures ||
			(failures == bestFailures && st.LastAt.Before(bestAt)) {
			best, bestFailures, bestAt = name, failures, st.LastAt
		}
	}
	return best
}
```

- [ ] **Step 5: Run the tests to verify they pass**

Run: `go test ./internal/store/ -v`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add internal/store/
git commit -m "feat(store): exam configuration and persisted progress

Saves atomically through a temporary file and rename, and treats corrupt
state as empty rather than refusing to start: losing statistics is a
nuisance, being unable to open the application is not.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

