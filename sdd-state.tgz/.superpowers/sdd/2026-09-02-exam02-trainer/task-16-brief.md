### Task 16: Level 3 content

**Files:**
- Modify: `meta.yaml` in all 15 Level 3 exercise directories
- Create: `driver.c` in the 5 function-kind directories
- Create: `cases.txt` in all 15 directories

**Interfaces:**
- Consumes: Tasks 2, 6, 7.
- Produces: 15 gradable exercises, so `GradableByLevel(3)` is no longer empty.

- [ ] **Step 1: Confirm every meta.yaml**

| Exercise | kind | prototype | allowed_functions |
| --- | --- | --- | --- |
| add_prime_sum | program | — | write, exit |
| epur_str | program | — | write |
| expand_str | program | — | write |
| ft_atoi_base | function | `int ft_atoi_base(const char *str, int str_base);` | none |
| ft_list_size | function | `int ft_list_size(t_list *begin_list);` | none |
| ft_range | function | `int *ft_range(int start, int end);` | malloc |
| ft_rrange | function | `int *ft_rrange(int start, int end);` | malloc |
| hidenp | program | — | write |
| lcm | function | `unsigned int lcm(unsigned int a, unsigned int b);` | none |
| paramsum | program | — | write |
| pgcd | program | — | printf, atoi, malloc, free |
| print_hex | program | — | write |
| rstr_capitalizer | program | — | write |
| str_capitalizer | program | — | write |
| tab_mult | program | — | write |

`ft_list_size` ships a header upstream; its `meta.yaml` must carry
`header: ft_list.h` so Task 10 copies it into the candidate's workspace.

- [ ] **Step 2: Write the five drivers**

`ft_range` and `ft_rrange` return an allocated array whose length is implied by
the arguments, so the driver prints every element:

```c
#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int start, int end);

int	main(int argc, char **argv)
{
	int	start;
	int	end;
	int	len;
	int	i;
	int	*range;

	if (argc < 3)
		return (1);
	start = atoi(argv[1]);
	end = atoi(argv[2]);
	range = ft_range(start, end);
	if (!range)
	{
		printf("(null)\n");
		return (0);
	}
	if (start > end)
		len = start - end + 1;
	else
		len = end - start + 1;
	i = 0;
	while (i < len)
	{
		printf("%d ", range[i]);
		i++;
	}
	printf("|end\n");
	return (0);
}
```

`ft_list_size` is the first driver that must build a linked list. It includes
the upstream header and links the list from argv:

```c
#include <stdio.h>
#include <stdlib.h>
#include "ft_list.h"

int	ft_list_size(t_list *begin_list);

int	main(int argc, char **argv)
{
	t_list	*head;
	t_list	*node;
	int		i;

	head = NULL;
	i = argc - 1;
	while (i >= 1)
	{
		node = malloc(sizeof(t_list));
		node->data = argv[i];
		node->next = head;
		head = node;
		i--;
	}
	printf("%d\n", ft_list_size(head));
	return (0);
}
```

Check the upstream header for the exact field names before writing this: the
struct's members are what the driver must use, and they differ between the
list exercises.

- [ ] **Step 3: Write a case file for each of the 15**

As Task 15's step 3. For `ft_range` and `ft_rrange` include `start > end`,
`start == end`, and a negative span, all of which the subject defines.
For `ft_list_size` include the empty list, which means running with no
arguments.

- [ ] **Step 4: Run the suite**

Run: `go test ./internal/grader/ -run 'TestEveryReference|TestMutated' -v`
Iterate until green across all 46 ready exercises.

- [ ] **Step 5: Run everything**

Run: `go test ./...`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add internal/catalog/exercises/
git commit -m "feat(data): Level 3 drivers, cases and confirmed metadata

Includes the first linked-list driver, which builds its list from argv
using the header the exercise ships.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

