# Task 2 Report: Exercise types, case files, and the embedded loader

## Summary

Implemented `internal/catalog/exercise.go` (Kind, Case, Meta, Exercise,
Gradable, Timeout), `internal/catalog/cases.go` (ParseCases), and
`internal/catalog/load.go` (Catalog, Load, All, ByLevel, GradableByLevel,
ByName), each preceded by its failing test as specified in the brief.
Followed the brief's code verbatim. Added `gopkg.in/yaml.v3 v3.0.1` as the
only new dependency, pinned exactly.

Two TDD cycles, as the brief lays out: the case parser first, then the
loader.

## Cycle 1: case parser (ParseCases / Case)

### RED

Created `internal/catalog/cases_test.go` with the brief's four tests
(`TestParseCases`, `TestParseCasesDistinguishesEmptyArgFromNoArg`,
`TestParseCasesRejectsMalformedLine`, `TestParseCasesRejectsEmptyFile`).

Command:
```
go test ./internal/catalog/ -run TestParseCases -v
```

Output:
```
# exam02/internal/catalog [exam02/internal/catalog.test]
internal/catalog/cases_test.go:15:14: undefined: ParseCases
internal/catalog/cases_test.go:19:12: undefined: Case
internal/catalog/cases_test.go:33:14: undefined: ParseCases
internal/catalog/cases_test.go:46:15: undefined: ParseCases
internal/catalog/cases_test.go:53:15: undefined: ParseCases
FAIL	exam02/internal/catalog [build failed]
FAIL
```

This is the expected failure: `ParseCases` and `Case` did not exist yet, so
the package fails to compile — exactly what the brief predicted
(`undefined: ParseCases`, `undefined: Case`).

### GREEN

Created `internal/catalog/exercise.go` (defines `Case`, `Kind`, `Meta`,
`Exercise`, `Gradable`, `Timeout`) and `internal/catalog/cases.go` (defines
`ParseCases`), both copied verbatim from the brief.

Command:
```
go test ./internal/catalog/ -run TestParseCases -v
```

Output:
```
=== RUN   TestParseCases
--- PASS: TestParseCases (0.00s)
=== RUN   TestParseCasesDistinguishesEmptyArgFromNoArg
--- PASS: TestParseCasesDistinguishesEmptyArgFromNoArg (0.00s)
=== RUN   TestParseCasesRejectsMalformedLine
--- PASS: TestParseCasesRejectsMalformedLine (0.00s)
=== RUN   TestParseCasesRejectsEmptyFile
--- PASS: TestParseCasesRejectsEmptyFile (0.00s)
PASS
ok  	exam02/internal/catalog	0.002s
```

Ran the whole package too (`go test ./... -v`) to confirm Task 1's
`TestParseSubject*` tests still passed alongside the new ones — they did.

## Cycle 2: loader (Load / Catalog)

### RED

Created `internal/catalog/load_test.go` with the brief's six tests
(`TestLoadReadsExercises`, `TestLoadProgramKindNeedsNoDriver`,
`TestLoadRejectsFunctionExerciseWithCasesButNoDriver`,
`TestLoadAcceptsAnUnauthoredExerciseAsNonGradable`,
`TestGradableByLevelExcludesUnauthored`, `TestByLevelIsSortedByName`),
using the `testFS()` two-exercise `fstest.MapFS` fixture (`ft_strlen`,
kind function; `rot_13`, kind program).

Command:
```
go test ./internal/catalog/ -run 'TestLoad|TestByLevel' -v
```

Output:
```
# exam02/internal/catalog [exam02/internal/catalog.test]
internal/catalog/load_test.go:30:12: undefined: Load
internal/catalog/load_test.go:59:12: undefined: Load
internal/catalog/load_test.go:74:15: undefined: Load
internal/catalog/load_test.go:86:12: undefined: Load
internal/catalog/load_test.go:106:12: undefined: Load
internal/catalog/load_test.go:120:12: undefined: Load
FAIL	exam02/internal/catalog [build failed]
FAIL
```

Expected: `Load` did not exist yet, so the package fails to compile —
matches the brief's predicted `undefined: Load`.

### GREEN

Created `internal/catalog/load.go` verbatim from the brief: `Catalog`
struct (`byName map[string]Exercise`, sorted `names []string`), `Load(fsys
fs.FS) (*Catalog, error)` which walks `exercises/*/`, reads `meta.yaml`
(via `yaml.Unmarshal`), `subject.md`, `reference.c` (required),
`spanish.md` and `driver.c` (best-effort, absence is not an error), an
optional declared header, then `cases.txt` — with the three tolerance
rules the task context calls out:

1. Missing `cases.txt` → not an error; exercise loads with `Cases == nil`,
   `Driver` possibly empty, and `Gradable() == false`.
2. `cases.txt` present, `Kind == KindFunction`, `Driver == ""` → error
   (`"has cases but no driver.c, which a function exercise needs"`).
3. `cases.txt` present but malformed or empty → error, surfaced through
   `ParseCases`'s own error (`"parsing cases.txt: %w"`).

Added the dependency:
```
go get gopkg.in/yaml.v3@v3.0.1
```
```
go: added gopkg.in/yaml.v3 v3.0.1
```

`go get` initially added it as `// indirect` in `go.mod` (nothing had been
built against it yet in that pass); ran `go build ./...` then `go mod
tidy` to resolve it to a direct, non-indirect requirement, since
`load.go` imports it directly:
```
go build ./...
go mod tidy
```
Resulting `go.mod`:
```
module exam02

go 1.24

require gopkg.in/yaml.v3 v3.0.1
```
`go.sum` carries `gopkg.in/yaml.v3 v3.0.1` and its test-only transitive
dependency `gopkg.in/check.v1` (checksum entries only, not a module
requirement — normal for yaml.v3).

Command:
```
go test ./internal/catalog/ -run 'TestLoad|TestByLevel' -v
```

Output:
```
=== RUN   TestLoadReadsExercises
--- PASS: TestLoadReadsExercises (0.00s)
=== RUN   TestLoadProgramKindNeedsNoDriver
--- PASS: TestLoadProgramKindNeedsNoDriver (0.00s)
=== RUN   TestLoadRejectsFunctionExerciseWithCasesButNoDriver
--- PASS: TestLoadRejectsFunctionExerciseWithCasesButNoDriver (0.00s)
=== RUN   TestLoadAcceptsAnUnauthoredExerciseAsNonGradable
--- PASS: TestLoadAcceptsAnUnauthoredExerciseAsNonGradable (0.00s)
=== RUN   TestByLevelIsSortedByName
--- PASS: TestByLevelIsSortedByName (0.00s)
PASS
ok  	exam02/internal/catalog	0.003s
```

(Note: `TestGradableByLevelExcludesUnauthored` doesn't match the
`TestLoad|TestByLevel` regex — that's the brief's literal Step 7 command,
reused verbatim for the RED/GREEN pair. It was confirmed passing in the
full-package run below.)

Full package run, confirming every test including
`TestGradableByLevelExcludesUnauthored` and all of Task 1's subject tests:
```
go test ./internal/catalog/ -v
```
```
=== RUN   TestParseCases
--- PASS: TestParseCases (0.00s)
=== RUN   TestParseCasesDistinguishesEmptyArgFromNoArg
--- PASS: TestParseCasesDistinguishesEmptyArgFromNoArg (0.00s)
=== RUN   TestParseCasesRejectsMalformedLine
--- PASS: TestParseCasesRejectsMalformedLine (0.00s)
=== RUN   TestParseCasesRejectsEmptyFile
--- PASS: TestParseCasesRejectsEmptyFile (0.00s)
=== RUN   TestLoadReadsExercises
--- PASS: TestLoadReadsExercises (0.00s)
=== RUN   TestLoadProgramKindNeedsNoDriver
--- PASS: TestLoadProgramKindNeedsNoDriver (0.00s)
=== RUN   TestLoadRejectsFunctionExerciseWithCasesButNoDriver
--- PASS: TestLoadRejectsFunctionExerciseWithCasesButNoDriver (0.00s)
=== RUN   TestLoadAcceptsAnUnauthoredExerciseAsNonGradable
--- PASS: TestLoadAcceptsAnUnauthoredExerciseAsNonGradable (0.00s)
=== RUN   TestGradableByLevelExcludesUnauthored
--- PASS: TestGradableByLevelExcludesUnauthored (0.00s)
=== RUN   TestByLevelIsSortedByName
--- PASS: TestByLevelIsSortedByName (0.00s)
=== RUN   TestParseSubjectReadsHeaderFields
--- PASS: TestParseSubjectReadsHeaderFields (0.00s)
=== RUN   TestParseSubjectAllowedFunctions
    (6 subtests)
--- PASS: TestParseSubjectAllowedFunctions (0.00s)
=== RUN   TestParseSubjectMultipleExpectedFilesTakesTheC
--- PASS: TestParseSubjectMultipleExpectedFilesTakesTheC (0.00s)
=== RUN   TestParseSubjectGlobExpectedFilesIsUnresolved
--- PASS: TestParseSubjectGlobExpectedFilesIsUnresolved (0.00s)
=== RUN   TestParseSubjectWithoutAssignmentNameIsAnError
--- PASS: TestParseSubjectWithoutAssignmentNameIsAnError (0.00s)
PASS
ok  	exam02/internal/catalog	0.003s
```

Also ran `go vet ./...`, `go build ./...`, and `gofmt -l .` — all clean,
no issues, no unformatted files.

## Files

- `internal/catalog/exercise.go` — `Kind`, `Case`, `Meta`, `Exercise`,
  `Gradable()`, `Timeout()`
- `internal/catalog/cases.go` — `ParseCases`
- `internal/catalog/cases_test.go` — the four case-parser tests
- `internal/catalog/load.go` — `Catalog`, `Load`, `All`, `ByLevel`,
  `GradableByLevel`, `ByName`
- `internal/catalog/load_test.go` — the six loader tests
- `go.mod` / `go.sum` — added `gopkg.in/yaml.v3 v3.0.1` as a direct,
  pinned dependency

## Commit

```
6751c25 feat(catalog): exercise types and embedded loader
```
7 files changed, 443 insertions(+): `go.mod`, `go.sum` (new),
`internal/catalog/cases.go`, `internal/catalog/cases_test.go`,
`internal/catalog/exercise.go`, `internal/catalog/load.go`,
`internal/catalog/load_test.go`.

## Deviations from the brief

None. All code was used verbatim as given in the brief; the loader's
tolerance rules (unauthored exercise loads as non-gradable, function
exercise with cases but no driver errors, empty/malformed cases.txt
errors) match the brief's code exactly and are exercised by the pinned
tests named in the task context.

## Concerns

None. The three tolerance rules called out in the task context are
implemented exactly as specified and covered by
`TestLoadRejectsFunctionExerciseWithCasesButNoDriver`,
`TestLoadAcceptsAnUnauthoredExerciseAsNonGradable`, and
`TestGradableByLevelExcludesUnauthored`, all passing. No other
dependencies were introduced beyond the one permitted
(`gopkg.in/yaml.v3 v3.0.1`, pinned exactly).
