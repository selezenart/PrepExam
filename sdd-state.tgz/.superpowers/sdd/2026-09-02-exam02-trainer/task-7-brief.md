### Task 7: Level 1 drivers, cases, and the suite that validates them

The vertical slice. When this task is green, the whole pipeline is proven against 12 real exercises and writing the remaining 44 is mechanical.

**Files:**
- Create: `data/exercises/ft_putstr/driver.c`, `data/exercises/ft_strcpy/driver.c`, `data/exercises/ft_strlen/driver.c`, `data/exercises/ft_swap/driver.c`
- Create: `cases.txt` in all 12 Level 1 exercise directories
- Create: `internal/catalog/embed.go`, `internal/grader/suite_test.go`
- Test: `internal/grader/suite_test.go`

**Interfaces:**
- Consumes: everything from Tasks 2, 5 and 6.
- Produces: `catalog.Embedded() (*Catalog, error)` — the production catalog, read from the embedded data.

- [ ] **Step 1: Write the four drivers**

A driver supplies `main`, calls the candidate's function, and prints the result so that a wrong answer shows up as different text. Drivers may use `printf` freely: they are our code, compiled separately, and are never subject to the allowed-functions check.

`data/exercises/ft_strlen/driver.c`:

```c
#include <stdio.h>

int	ft_strlen(char *str);

int	main(int argc, char **argv)
{
	if (argc < 2)
		return (1);
	printf("%d\n", ft_strlen(argv[1]));
	return (0);
}
```

`data/exercises/ft_putstr/driver.c`:

```c
#include <unistd.h>

void	ft_putstr(char *str);

int	main(int argc, char **argv)
{
	if (argc < 2)
		return (1);
	ft_putstr(argv[1]);
	write(1, "|end\n", 5);
	return (0);
}
```

The `|end` marker matters: without it a function that writes nothing and one that writes a trailing space look identical once the terminal has rendered them.

`data/exercises/ft_strcpy/driver.c`:

```c
#include <stdio.h>
#include <string.h>

char	*ft_strcpy(char *s1, char *s2);

int	main(int argc, char **argv)
{
	char	dest[1024];
	char	*ret;

	if (argc < 2)
		return (1);
	memset(dest, '#', sizeof(dest));
	ret = ft_strcpy(dest, argv[1]);
	printf("[%s]\n", dest);
	printf("returns_dest=%d\n", ret == dest);
	printf("byte_after_nul=%c\n", dest[strlen(argv[1]) + 1]);
	return (0);
}
```

Filling the buffer with `#` and printing the byte after the terminator catches a copy that writes too much, which a plain string comparison would miss.

`data/exercises/ft_swap/driver.c`:

```c
#include <stdio.h>
#include <stdlib.h>

void	ft_swap(int *a, int *b);

int	main(int argc, char **argv)
{
	int	a;
	int	b;

	if (argc < 3)
		return (1);
	a = atoi(argv[1]);
	b = atoi(argv[2]);
	ft_swap(&a, &b);
	printf("%d %d\n", a, b);
	return (0);
}
```

- [ ] **Step 2: Write the case files**

Every case file must include the argument counts the subject calls out, because "if the number of arguments is not 1, display a newline" is the rule candidates forget most often.

`data/exercises/ft_strlen/cases.txt`:
```
{"args": ["hello"]}
{"args": [""]}
{"args": ["a"]}
{"args": ["with spaces and	tabs"]}
{"args": ["0123456789012345678901234567890123456789"]}
```

`data/exercises/ft_putstr/cases.txt`:
```
{"args": ["hello"]}
{"args": [""]}
{"args": ["multi\nline"]}
{"args": ["trailing space "]}
```

`data/exercises/ft_strcpy/cases.txt`:
```
{"args": ["hello"]}
{"args": [""]}
{"args": ["a"]}
{"args": ["a longer string to copy"]}
```

`data/exercises/ft_swap/cases.txt`:
```
{"args": ["1", "2"]}
{"args": ["0", "0"]}
{"args": ["-5", "5"]}
{"args": ["2147483647", "-2147483648"]}
```

`data/exercises/first_word/cases.txt`:
```
{"args": ["FOR PONY"]}
{"args": ["this        ...       is sparta, then?"]}
{"args": [""]}
{"args": ["   "]}
{"args": ["  lorem,ipsum  "]}
{"args": []}
{"args": ["a", "b"]}
```

`data/exercises/fizzbuzz/cases.txt`:
```
{"args": []}
```

`data/exercises/repeat_alpha/cases.txt`:
```
{"args": ["abc"]}
{"args": ["Alex Antoine Hilaire Zebulon"]}
{"args": ["abcdefghijklmnopqrstuvwxyz"]}
{"args": [""]}
{"args": []}
{"args": ["a", "b"]}
```

`data/exercises/rev_print/cases.txt`:
```
{"args": ["zaz"]}
{"args": ["dub0 a POIL"]}
{"args": [""]}
{"args": ["a"]}
{"args": []}
{"args": ["a", "b"]}
```

`data/exercises/rot_13/cases.txt`:
```
{"args": ["abc"]}
{"args": ["Salut, comment tu vas ? 32 chars cheer"]}
{"args": ["zZ"]}
{"args": ["nopqrstuvwxyz"]}
{"args": [""]}
{"args": []}
{"args": ["a", "b"]}
```

`data/exercises/rotone/cases.txt`:
```
{"args": ["abc"]}
{"args": ["zZ"]}
{"args": ["Les stagiaires du staff ne sentent pas toujours tres bon."]}
{"args": [""]}
{"args": []}
{"args": ["a", "b"]}
```

`data/exercises/search_and_replace/cases.txt`:
```
{"args": ["Papache est un sabre", "a", "o"]}
{"args": ["zaz", "z", "m"]}
{"args": ["zaz", "v", "m"]}
{"args": ["", "a", "b"]}
{"args": ["abc", "a"]}
{"args": []}
{"args": ["abc", "ab", "c"]}
```

`data/exercises/ulstr/cases.txt`:
```
{"args": ["L'eSPrit nE peUt plUs pRogResSer s'Il staGne."]}
{"args": ["abcXYZ123"]}
{"args": [""]}
{"args": []}
{"args": ["a", "b"]}
```

- [ ] **Step 3: Write the embed file**

Create `internal/catalog/embed.go`:

```go
package catalog

import (
	"embed"
	"io/fs"
)

//go:embed all:exercises
var embedded embed.FS

// Embedded returns the catalog compiled into the binary. Using all: means
// files are included even if a future exercise directory starts with a dot or
// an underscore, which go:embed would otherwise skip.
func Embedded() (*Catalog, error) {
	return Load(embedded)
}

// EmbeddedFS exposes the raw filesystem, for tests that need to check what
// was actually compiled in.
func EmbeddedFS() fs.FS { return embedded }
```

- [ ] **Step 4: Move the data under the catalog package**

`go:embed` can only read files in or below its own directory, so the generated tree has to live beside `embed.go`.

```bash
git mv data/exercises internal/catalog/exercises
rmdir data 2>/dev/null || true
```

Then update the importer's default output path in `tools/import/main.go`:

```go
	dst := flag.String("dst", "internal/catalog/exercises", "output directory")
```

- [ ] **Step 5: Write the failing suite test**

Create `internal/grader/suite_test.go`:

```go
package grader

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"exam02/internal/catalog"
)

// readyExercises returns the exercises that have the driver and cases needed
// to be graded. Levels 2 to 4 arrive in a follow-on plan; until then they are
// present as subjects but not yet gradable, and skipping them here keeps the
// suite honest rather than silently green.
func readyExercises(t *testing.T) []catalog.Exercise {
	t.Helper()
	c, err := catalog.Embedded()
	if err != nil {
		t.Fatalf("catalog.Embedded() error = %v", err)
	}
	var out []catalog.Exercise
	for _, ex := range c.All() {
		if len(ex.Cases) > 0 {
			out = append(out, ex)
		}
	}
	return out
}

func requireCC(t *testing.T) {
	t.Helper()
	if _, err := exec.LookPath("cc"); err != nil {
		t.Skip("cc not available")
	}
}

// TestEveryReferenceSolutionPasses is the load-bearing test of this project.
// It validates every driver and every case file at once: if a driver calls the
// function wrongly or a case file expects something the subject does not
// require, the reference itself fails here.
func TestEveryReferenceSolutionPasses(t *testing.T) {
	requireCC(t)
	exercises := readyExercises(t)
	if len(exercises) < 12 {
		t.Fatalf("only %d exercises are ready; Level 1 has 12", len(exercises))
	}
	g := New()
	for _, ex := range exercises {
		t.Run(ex.Name, func(t *testing.T) {
			t.Parallel()
			dir := t.TempDir()
			path := filepath.Join(dir, ex.ExpectedFile)
			if err := os.WriteFile(path, []byte(ex.Reference), 0o644); err != nil {
				t.Fatal(err)
			}
			v, err := g.Grade(context.Background(), ex, path)
			if err != nil {
				t.Fatalf("Grade() error = %v", err)
			}
			if !v.Passed() {
				t.Errorf("the reference solution failed its own grader: %s: %s\n%s",
					v.Status, v.Summary, v.Detail)
			}
		})
	}
}

// TestMutatedReferencesFail proves the case files actually discriminate.
// Without it, a driver that printed nothing would sail through the test above
// while testing nothing at all.
func TestMutatedReferencesFail(t *testing.T) {
	requireCC(t)
	g := New()
	for _, ex := range readyExercises(t) {
		mutated, ok := mutate(ex.Reference)
		if !ok {
			t.Errorf("%s: no mutation could be applied; add a case that would catch one", ex.Name)
			continue
		}
		t.Run(ex.Name, func(t *testing.T) {
			t.Parallel()
			dir := t.TempDir()
			path := filepath.Join(dir, ex.ExpectedFile)
			if err := os.WriteFile(path, []byte(mutated), 0o644); err != nil {
				t.Fatal(err)
			}
			v, err := g.Grade(context.Background(), ex, path)
			if err != nil {
				t.Fatalf("Grade() error = %v", err)
			}
			if v.Passed() {
				t.Errorf("a mutated reference still passed; the cases do not discriminate")
			}
		})
	}
}

// mutate makes one behaviour-changing edit to C source. It tries each
// replacement in turn and stops at the first that applies.
func mutate(src string) (string, bool) {
	replacements := []struct{ from, to string }{
		{" <= ", " < "},
		{" >= ", " > "},
		{" == ", " != "},
		{" + 1", " + 2"},
		{"i++", "i += 2"},
		{" 13", " 12"},
		{" 26", " 25"},
	}
	for _, r := range replacements {
		if strings.Contains(src, r.from) {
			return strings.Replace(src, r.from, r.to, 1), true
		}
	}
	return "", false
}
```

- [ ] **Step 6: Run the suite and fix what it finds**

Run: `go test ./internal/grader/ -run 'TestEveryReference|TestMutated' -v`

Expected on the first run: some failures. That is the point of the task. Work through them:

- A reference failing with `wrong output` usually means the driver prints something the reference cannot produce — fix the driver.
- A reference failing with `forbidden function` means `allowed_functions` in that `meta.yaml` is wrong — check it against the subject.
- A mutated reference still passing means the case file does not exercise the mutated path — add a case that does.
- `no mutation could be applied` means the reference contains none of the patterns; add a pattern to `mutate` that fits it.

Iterate until both tests are fully green for all 12 Level 1 exercises.

- [ ] **Step 7: Run the whole suite**

Run: `go test ./... -v`
Expected: PASS everywhere.

- [ ] **Step 8: Commit**

```bash
git add internal/catalog/ internal/grader/suite_test.go tools/
git commit -m "feat(data): Level 1 drivers, cases, and the suite that validates them

Grading all 12 reference solutions proves every driver and case file at
once. The mutation test is what keeps that honest: without it a driver
that printed nothing would pass while testing nothing.

Exercise data moves under internal/catalog because go:embed cannot read
above its own directory.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

