### Task 1: Module skeleton and subject parser

The parser reads the machine-readable header of an upstream subject. Getting it right first means every later task can rely on structured exercise metadata.

**Files:**
- Create: `go.mod`, `.gitignore` (already exists, leave it), `internal/catalog/subject.go`
- Test: `internal/catalog/subject_test.go`

**Interfaces:**
- Consumes: nothing.
- Produces: `catalog.SubjectMeta{Name, ExpectedFile string; AllowedFunctions []string}` and `catalog.ParseSubject(md string) (SubjectMeta, error)`.

- [ ] **Step 1: Initialise the module**

```bash
cd /home/aselezen/exam02
go mod init exam02
go mod edit -go=1.24
```

- [ ] **Step 2: Write the failing test**

Create `internal/catalog/subject_test.go`. The five cases below are the five spellings that actually occur upstream — an ordinary list, `None`, `-`, an empty value, and a multi-file `Expected files`.

```go
package catalog

import (
	"reflect"
	"testing"
)

const strlenSubject = "## Subject\n\n```BASH\n" +
	"Assignment name  : ft_strlen\n" +
	"Expected files   : ft_strlen.c\n" +
	"Allowed functions: \n" +
	"--------------------------------------------------------------------------------\n\n" +
	"Write a function that returns the length of a string.\n\n" +
	"Your function must be declared as follows:\n\n" +
	"int\tft_strlen(char *str);\n```\n"

func TestParseSubjectReadsHeaderFields(t *testing.T) {
	got, err := ParseSubject(strlenSubject)
	if err != nil {
		t.Fatalf("ParseSubject() error = %v", err)
	}
	if got.Name != "ft_strlen" {
		t.Errorf("Name = %q, want %q", got.Name, "ft_strlen")
	}
	if got.ExpectedFile != "ft_strlen.c" {
		t.Errorf("ExpectedFile = %q, want %q", got.ExpectedFile, "ft_strlen.c")
	}
	if len(got.AllowedFunctions) != 0 {
		t.Errorf("AllowedFunctions = %v, want empty", got.AllowedFunctions)
	}
}

func TestParseSubjectAllowedFunctions(t *testing.T) {
	tests := []struct {
		name  string
		field string
		want  []string
	}{
		{"empty means none", "", nil},
		{"literal None", "None", nil},
		{"literal dash", "-", nil},
		{"single", "malloc", []string{"malloc"}},
		{"list", "write, malloc, free", []string{"write", "malloc", "free"}},
		{"ragged spacing", "  write ,malloc  ", []string{"write", "malloc"}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			md := "Assignment name  : x\nExpected files   : x.c\nAllowed functions: " + tt.field + "\n"
			got, err := ParseSubject(md)
			if err != nil {
				t.Fatalf("ParseSubject() error = %v", err)
			}
			if !reflect.DeepEqual(got.AllowedFunctions, tt.want) {
				t.Errorf("AllowedFunctions = %#v, want %#v", got.AllowedFunctions, tt.want)
			}
		})
	}
}

func TestParseSubjectMultipleExpectedFilesTakesTheC(t *testing.T) {
	md := "Assignment name  : ft_list_size\nExpected files   : ft_list_size.c, ft_list.h\nAllowed functions: \n"
	got, err := ParseSubject(md)
	if err != nil {
		t.Fatalf("ParseSubject() error = %v", err)
	}
	if got.ExpectedFile != "ft_list_size.c" {
		t.Errorf("ExpectedFile = %q, want %q", got.ExpectedFile, "ft_list_size.c")
	}
}

func TestParseSubjectGlobExpectedFilesIsUnresolved(t *testing.T) {
	// flood_fill and sort_list write "*.c, *.h". A glob cannot be resolved
	// automatically, so the parser reports no expected file and meta.yaml
	// supplies one by hand.
	md := "Assignment name  : flood_fill\nExpected files   : *.c, *.h\nAllowed functions: \n"
	got, err := ParseSubject(md)
	if err != nil {
		t.Fatalf("ParseSubject() error = %v", err)
	}
	if got.ExpectedFile != "" {
		t.Errorf("ExpectedFile = %q, want empty for a glob", got.ExpectedFile)
	}
}

func TestParseSubjectWithoutAssignmentNameIsAnError(t *testing.T) {
	if _, err := ParseSubject("just prose, no header\n"); err == nil {
		t.Fatal("ParseSubject() error = nil, want an error")
	}
}
```

- [ ] **Step 3: Run the test to verify it fails**

Run: `go test ./internal/catalog/ -run TestParseSubject -v`
Expected: FAIL — `undefined: ParseSubject`.

- [ ] **Step 4: Write the implementation**

Create `internal/catalog/subject.go`:

```go
// Package catalog holds the exercise data: the upstream subjects, the
// reference solutions used as a grading oracle, and the drivers and input
// cases written for this project.
package catalog

import (
	"bufio"
	"fmt"
	"strings"
)

// SubjectMeta is the machine-readable header of an upstream exercise subject.
type SubjectMeta struct {
	Name             string
	ExpectedFile     string
	AllowedFunctions []string
}

// ParseSubject extracts the header fields from an upstream subject document.
//
// ExpectedFile may come back empty: four subjects write a glob such as
// "*.c, *.h" rather than naming a file, and a glob cannot be resolved without
// knowing the exercise. Those four carry a hand-written expected_file in their
// meta.yaml instead.
func ParseSubject(md string) (SubjectMeta, error) {
	var m SubjectMeta
	scanner := bufio.NewScanner(strings.NewReader(md))
	for scanner.Scan() {
		key, value, ok := splitField(scanner.Text())
		if !ok {
			continue
		}
		switch key {
		case "Assignment name":
			m.Name = value
		case "Expected files":
			m.ExpectedFile = sourceFile(value)
		case "Allowed functions":
			m.AllowedFunctions = parseAllowedFunctions(value)
		}
	}
	if err := scanner.Err(); err != nil {
		return m, fmt.Errorf("reading subject: %w", err)
	}
	if m.Name == "" {
		return m, fmt.Errorf("subject has no assignment name")
	}
	return m, nil
}

// splitField splits "Assignment name  : ft_strlen" into its key and value.
// Subject prose also contains colons, but only the three known keys are acted
// on, so a false split is harmless.
func splitField(line string) (key, value string, ok bool) {
	key, value, ok = strings.Cut(line, ":")
	if !ok {
		return "", "", false
	}
	return strings.TrimSpace(key), strings.TrimSpace(value), true
}

// sourceFile picks the .c file the candidate is expected to write out of an
// "Expected files" value. The value may name one file, name a .c alongside a
// header that is provided rather than written, or be a glob.
func sourceFile(value string) string {
	for _, part := range strings.Split(value, ",") {
		part = strings.TrimSpace(part)
		if strings.HasPrefix(part, "*") {
			continue
		}
		if strings.HasSuffix(part, ".c") {
			return part
		}
	}
	return ""
}

// parseAllowedFunctions reads the allowed-functions field. Upstream writes an
// empty value, "None", or "-" to mean that no library function may be used.
func parseAllowedFunctions(value string) []string {
	if value == "" || value == "-" || strings.EqualFold(value, "none") {
		return nil
	}
	var out []string
	for _, part := range strings.Split(value, ",") {
		if fn := strings.TrimSpace(part); fn != "" {
			out = append(out, fn)
		}
	}
	return out
}
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `go test ./internal/catalog/ -v`
Expected: PASS, all subtests.

- [ ] **Step 6: Commit**

```bash
git add go.mod internal/catalog/
git commit -m "feat(catalog): parse upstream exercise subjects

Reads assignment name, expected file and allowed functions out of the
subject header. Handles the five spellings that occur upstream, including
the four subjects whose expected files are a glob and so cannot be
resolved automatically.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

