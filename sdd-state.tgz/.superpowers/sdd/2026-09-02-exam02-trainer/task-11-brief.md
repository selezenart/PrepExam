### Task 11: TUI shell — menu and exercise screen

**Files:**
- Create: `internal/ui/styles.go`, `internal/ui/model.go`, `internal/ui/menu.go`, `internal/ui/exercise.go`
- Test: `internal/ui/model_test.go`

**Interfaces:**
- Consumes: everything from Tasks 2, 6, 8, 9, 10.
- Produces: `ui.Model`, `ui.New(deps Deps) Model`, `ui.Deps{Catalog, Grader, Config, State, StateDir, Root string}`, and the Bubble Tea `Init`/`Update`/`View` triple.

- [ ] **Step 1: Add the TUI dependencies**

```bash
go get github.com/charmbracelet/bubbletea@v1.3.10
go get github.com/charmbracelet/lipgloss@v1.1.0
```

- [ ] **Step 2: Write the styles**

Create `internal/ui/styles.go`:

```go
package ui

import "github.com/charmbracelet/lipgloss"

// Colours are chosen from the 256-colour palette so the interface looks the
// same in the terminals 42 machines actually run.
var (
	styleTitle = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color("87"))
	styleDim   = lipgloss.NewStyle().Foreground(lipgloss.Color("244"))
	styleOK    = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color("47"))
	styleKO    = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color("203"))
	styleWarn  = lipgloss.NewStyle().Foreground(lipgloss.Color("214"))
	styleKey   = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color("213"))

	styleBox = lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(lipgloss.Color("240")).
			Padding(0, 1)
)
```

- [ ] **Step 3: Write the failing model test**

Create `internal/ui/model_test.go`:

```go
package ui

import (
	"strings"
	"testing"
	"testing/fstest"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"exam02/internal/catalog"
	"exam02/internal/grader"
	"exam02/internal/store"
)

func testCatalog(t *testing.T) *catalog.Catalog {
	t.Helper()
	fsys := fstest.MapFS{}
	for _, name := range []string{"ft_strlen", "ft_atoi", "epur_str", "ft_split"} {
		level := map[string]int{"ft_strlen": 1, "ft_atoi": 2, "epur_str": 3, "ft_split": 4}[name]
		dir := "exercises/" + name + "/"
		fsys[dir+"meta.yaml"] = &fstest.MapFile{Data: []byte(
			"name: " + name + "\nlevel: " + string(rune('0'+level)) + "\nkind: program\n" +
				"expected_file: " + name + ".c\nallowed_functions: []\nprototype: \"\"\n")}
		fsys[dir+"subject.md"] = &fstest.MapFile{Data: []byte("subject for " + name)}
		fsys[dir+"reference.c"] = &fstest.MapFile{Data: []byte("int main(void){return 0;}")}
		fsys[dir+"cases.txt"] = &fstest.MapFile{Data: []byte("{\"args\": []}\n")}
	}
	c, err := catalog.Load(fsys)
	if err != nil {
		t.Fatalf("catalog.Load() error = %v", err)
	}
	return c
}

func newTestModel(t *testing.T) Model {
	t.Helper()
	state, _ := store.Load(t.TempDir())
	return New(Deps{
		Catalog:  testCatalog(t),
		Grader:   grader.New(),
		Config:   store.DefaultConfig(),
		State:    state,
		StateDir: t.TempDir(),
		Root:     t.TempDir(),
	})
}

func key(s string) tea.KeyMsg {
	if len(s) == 1 {
		return tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune(s)}
	}
	return tea.KeyMsg{Type: tea.KeyEnter}
}

func TestMenuIsTheFirstScreen(t *testing.T) {
	m := newTestModel(t)
	view := m.View()
	for _, want := range []string{"Exam", "Practice", "Quit"} {
		if !strings.Contains(view, want) {
			t.Errorf("menu does not offer %q:\n%s", want, view)
		}
	}
}

func TestQuittingFromTheMenu(t *testing.T) {
	m := newTestModel(t)
	_, cmd := m.Update(key("q"))
	if cmd == nil {
		t.Fatal("pressing q returned no command, want tea.Quit")
	}
	if msg := cmd(); msg == nil {
		t.Error("the command produced no message, want a quit message")
	}
}

func TestStartingAnExamShowsTheSubjectAndTheClock(t *testing.T) {
	m := newTestModel(t)
	next, _ := m.Update(key("1"))
	view := next.View()
	if !strings.Contains(view, "subject for") {
		t.Errorf("the exam screen does not show a subject:\n%s", view)
	}
	if !strings.Contains(view, "Level 1") {
		t.Errorf("the exam screen does not show the level:\n%s", view)
	}
	if !strings.Contains(view, "0 / 100") {
		t.Errorf("the exam screen does not show points against the pass mark:\n%s", view)
	}
}

func TestPracticeListsEveryExercise(t *testing.T) {
	m := newTestModel(t)
	next, _ := m.Update(key("2"))
	view := next.View()
	for _, want := range []string{"ft_strlen", "ft_atoi", "epur_str", "ft_split"} {
		if !strings.Contains(view, want) {
			t.Errorf("the practice list is missing %q:\n%s", want, view)
		}
	}
}

func TestExamScreenRendersTheRemainingTime(t *testing.T) {
	m := newTestModel(t)
	next, _ := m.Update(key("1"))
	// Three hours, so the clock should read close to it on the first frame.
	if !strings.Contains(next.View(), "2:59") && !strings.Contains(next.View(), "3:00") {
		t.Errorf("the exam screen does not show a countdown:\n%s", next.View())
	}
}

func TestTickAdvancesTheClockWithoutEndingTheExam(t *testing.T) {
	m := newTestModel(t)
	next, _ := m.Update(key("1"))
	after, cmd := next.Update(tickMsg(time.Now()))
	if cmd == nil {
		t.Error("a tick did not schedule the next one; the clock would stop")
	}
	if !strings.Contains(after.View(), "Level 1") {
		t.Errorf("the exam screen was lost on a tick:\n%s", after.View())
	}
}
```

- [ ] **Step 4: Run it to verify it fails**

Run: `go test ./internal/ui/ -v`
Expected: FAIL — `undefined: New`.

- [ ] **Step 5: Write the model**

Create `internal/ui/model.go`:

```go
// Package ui is the terminal interface: a menu, a timed exam, and untimed
// practice, all driven by the grader underneath.
package ui

import (
	"math/rand"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"exam02/internal/catalog"
	"exam02/internal/grader"
	"exam02/internal/session"
	"exam02/internal/store"
)

// screen is which view is on show.
type screen int

const (
	screenMenu screen = iota
	screenExam
	screenPractice
	screenExercise
	screenResult
	screenAbout
)

// Deps is everything the interface needs from the rest of the application,
// passed in rather than constructed here so tests can substitute their own.
type Deps struct {
	Catalog  *catalog.Catalog
	Grader   *grader.Grader
	Config   store.Config
	State    *store.State
	StateDir string
	Root     string // where rendu/ is created
}

// Model is the Bubble Tea model for the whole application.
type Model struct {
	deps Deps

	screen   screen
	previous screen

	exam     *session.Exam
	practice []catalog.Exercise
	cursor   int

	current  catalog.Exercise
	srcPath  string
	verdict  *grader.Verdict
	grading  bool
	revealed bool
	spanish  bool

	status string
	err    error
	now    time.Time
	width  int
}

// tickMsg drives the countdown.
type tickMsg time.Time

// gradedMsg carries a finished grading run back to the interface.
type gradedMsg struct {
	verdict grader.Verdict
	err     error
}

// editorFinishedMsg arrives when the candidate leaves their editor.
type editorFinishedMsg struct{ err error }

// New builds the initial model, showing the menu.
func New(deps Deps) Model {
	return Model{deps: deps, screen: screenMenu, now: time.Now()}
}

// Init starts the clock.
func (m Model) Init() tea.Cmd { return tick() }

func tick() tea.Cmd {
	return tea.Tick(time.Second, func(t time.Time) tea.Msg { return tickMsg(t) })
}

// Update routes a message to the active screen.
func (m Model) Update(msg tea.Msg) (Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width = msg.Width
		return m, nil

	case tickMsg:
		m.now = time.Time(msg)
		if m.screen == screenExam && m.exam != nil && m.exam.Over(m.now) {
			m.screen = screenResult
		}
		return m, tick()

	case gradedMsg:
		return m.applyVerdict(msg)

	case editorFinishedMsg:
		if msg.err != nil {
			m.err = msg.err
		}
		return m, nil

	case tea.KeyMsg:
		return m.handleKey(msg)
	}
	return m, nil
}

func (m Model) handleKey(msg tea.KeyMsg) (Model, tea.Cmd) {
	if m.grading {
		return m, nil // ignore input while a compile is in flight
	}
	switch m.screen {
	case screenMenu:
		return m.updateMenu(msg)
	case screenPractice:
		return m.updatePractice(msg)
	case screenExam, screenExercise:
		return m.updateExercise(msg)
	case screenResult:
		if msg.String() == "q" {
			return m, tea.Quit
		}
		m.screen = screenMenu
		return m, nil
	case screenAbout:
		m.screen = screenMenu
		return m, nil
	}
	return m, nil
}

// View renders the active screen.
func (m Model) View() string {
	switch m.screen {
	case screenMenu:
		return m.viewMenu()
	case screenPractice:
		return m.viewPractice()
	case screenExam, screenExercise:
		return m.viewExercise()
	case screenResult:
		return m.viewResult()
	case screenAbout:
		return m.viewAbout()
	}
	return ""
}

// startExam draws the first exercise and switches to the exam screen.
func (m Model) startExam() (Model, tea.Cmd) {
	pools := map[int][]string{}
	for level := 1; level <= 4; level++ {
		for _, ex := range m.deps.Catalog.GradableByLevel(level) {
			pools[level] = append(pools[level], ex.Name)
		}
	}
	exam, err := session.NewExam(m.deps.Config, pools, rand.New(rand.NewSource(time.Now().UnixNano())), time.Now())
	if err != nil {
		m.err = err
		return m, nil
	}
	m.exam = exam
	m.screen = screenExam
	return m.loadCurrent()
}

// loadCurrent prepares the workspace for whichever exercise is now current.
func (m Model) loadCurrent() (Model, tea.Cmd) {
	name := m.current.Name
	if m.screen == screenExam && m.exam != nil {
		name = m.exam.Current()
	}
	ex, ok := m.deps.Catalog.ByName(name)
	if !ok {
		return m, nil
	}
	m.current = ex
	m.verdict = nil
	m.revealed = false
	m.spanish = false
	path, err := prepareWorkspace(m.deps.Root, ex)
	if err != nil {
		m.err = err
		return m, nil
	}
	m.srcPath = path
	return m, nil
}
```

- [ ] **Step 6: Write the menu**

Create `internal/ui/menu.go`:

```go
package ui

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
)

func (m Model) updateMenu(msg tea.KeyMsg) (Model, tea.Cmd) {
	switch msg.String() {
	case "q", "ctrl+c", "esc":
		return m, tea.Quit
	case "1":
		return m.startExam()
	case "2":
		m.practice = m.deps.Catalog.All()
		m.cursor = 0
		m.screen = screenPractice
		return m, nil
	case "3":
		m.screen = screenAbout
		return m, nil
	}
	return m, nil
}

func (m Model) viewMenu() string {
	var b strings.Builder
	b.WriteString(styleTitle.Render("Exam Rank 02 — practice") + "\n\n")

	total, passed := 0, 0
	for _, ex := range m.deps.Catalog.All() {
		total++
		if st, ok := m.deps.State.Exercises[ex.Name]; ok && st.Passes > 0 {
			passed++
		}
	}
	b.WriteString(styleDim.Render(fmt.Sprintf("%d of %d exercises passed at least once", passed, total)) + "\n\n")

	b.WriteString(styleKey.Render("1") + "  Exam        three hours, one exercise per level, 100 points to pass\n")
	b.WriteString(styleKey.Render("2") + "  Practice    pick any exercise, no clock, solutions available\n")
	b.WriteString(styleKey.Render("3") + "  About\n")
	b.WriteString(styleKey.Render("q") + "  Quit\n")

	if m.err != nil {
		b.WriteString("\n" + styleKO.Render("error: "+m.err.Error()) + "\n")
	}
	return b.String()
}

func (m Model) viewAbout() string {
	var b strings.Builder
	b.WriteString(styleTitle.Render("About") + "\n\n")
	b.WriteString("A practice tool for the 42 Common Core Exam Rank 02.\n\n")
	b.WriteString("Exercise subjects and the reference solutions used for grading come from\n")
	b.WriteString(styleDim.Render("github.com/alexhiguera/Exam_Rank_02_42_School") + "\n")
	b.WriteString("MIT licensed, Copyright (c) 2026 Alex Higuera.\n\n")
	b.WriteString(styleWarn.Render("This is practice. The real exam is graded by the Moulinette,") + "\n")
	b.WriteString(styleWarn.Render("in a closed environment, and its rules are the ones that count.") + "\n\n")
	b.WriteString(styleDim.Render("any key to go back"))
	return b.String()
}
```

- [ ] **Step 7: Write the exercise screen**

Create `internal/ui/exercise.go`:

```go
package ui

import (
	"context"
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"exam02/internal/catalog"
	"exam02/internal/grader"
	"exam02/internal/workspace"
)

// prepareWorkspace is a variable so tests can avoid touching the filesystem.
var prepareWorkspace = workspace.Prepare

func (m Model) updateExercise(msg tea.KeyMsg) (Model, tea.Cmd) {
	switch msg.String() {
	case "ctrl+c":
		return m, tea.Quit

	case "q", "esc":
		if m.screen == screenExam {
			m.screen = screenResult
			return m, nil
		}
		m.screen = screenPractice
		return m, nil

	case "g":
		m.grading = true
		m.status = "compiling…"
		return m, m.gradeCmd()

	case "e":
		cmd := workspace.EditorCommand(m.srcPath)
		return m, tea.ExecProcess(cmd, func(err error) tea.Msg {
			return editorFinishedMsg{err: err}
		})

	case "r":
		if m.screen == screenPractice || m.screen == screenExercise {
			m.revealed = !m.revealed
		}
		return m, nil

	case "x":
		if m.screen == screenExercise && m.current.Spanish != "" {
			m.spanish = !m.spanish
		}
		return m, nil
	}
	return m, nil
}

// gradeCmd runs the grader off the interface goroutine so the clock keeps
// ticking while a compile is in flight.
func (m Model) gradeCmd() tea.Cmd {
	ex, path, g := m.current, m.srcPath, m.deps.Grader
	return func() tea.Msg {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()
		v, err := g.Grade(ctx, ex, path)
		return gradedMsg{verdict: v, err: err}
	}
}

// applyVerdict records the outcome and moves the exam on.
func (m Model) applyVerdict(msg gradedMsg) (Model, tea.Cmd) {
	m.grading = false
	m.status = ""
	if msg.err != nil {
		m.err = msg.err
		return m, nil
	}
	v := msg.verdict
	m.verdict = &v

	m.deps.State.Record(m.current.Name, string(v.Status), v.Passed())
	if err := m.deps.State.Save(m.deps.StateDir); err != nil {
		m.err = err
	}

	if m.screen == screenExam && m.exam != nil {
		m.exam.Record(v.Passed(), time.Now())
		if m.exam.Over(time.Now()) {
			m.screen = screenResult
			return m, nil
		}
		if v.Passed() {
			return m.loadCurrent()
		}
		// A failure redraws a different exercise from the same level; the
		// verdict stays on screen until the candidate moves on.
		next, cmd := m.loadCurrent()
		next.verdict = &v
		return next, cmd
	}
	return m, nil
}

func (m Model) viewExercise() string {
	var b strings.Builder

	if m.screen == screenExam && m.exam != nil {
		remaining := m.exam.Remaining(m.now)
		b.WriteString(styleTitle.Render(fmt.Sprintf(
			"Level %d   %d / %d points   %s left",
			m.exam.Level(), m.exam.Points(), m.deps.Config.PassMark, clock(remaining))))
		if remaining < 10*time.Minute {
			b.WriteString("  " + styleWarn.Render("!"))
		}
		b.WriteString("\n\n")
	} else {
		b.WriteString(styleTitle.Render(fmt.Sprintf("%s   level %d", m.current.Name, m.current.Level)) + "\n\n")
	}

	b.WriteString(styleBox.Render(strings.TrimSpace(m.current.Subject)) + "\n\n")
	b.WriteString(styleDim.Render("write your answer in  ") + m.srcPath + "\n")
	if len(m.current.AllowedFunctions) > 0 {
		b.WriteString(styleDim.Render("allowed: ") + strings.Join(m.current.AllowedFunctions, ", ") + "\n")
	} else {
		b.WriteString(styleDim.Render("allowed: nothing") + "\n")
	}
	b.WriteString("\n")

	switch {
	case m.grading:
		b.WriteString(m.status + "\n")
	case m.verdict != nil:
		b.WriteString(renderVerdict(*m.verdict) + "\n")
	}

	if m.revealed {
		b.WriteString("\n" + styleWarn.Render("reference solution") + "\n")
		b.WriteString(styleBox.Render(strings.TrimSpace(m.current.Reference)) + "\n")
	}
	if m.spanish {
		b.WriteString("\n" + styleBox.Render(strings.TrimSpace(m.current.Spanish)) + "\n")
	}

	b.WriteString("\n" + m.keyHints())
	return b.String()
}

func (m Model) keyHints() string {
	hints := []string{
		styleKey.Render("g") + " grade",
		styleKey.Render("e") + " edit",
	}
	if m.screen == screenExercise {
		hints = append(hints, styleKey.Render("r")+" solution")
		if m.current.Spanish != "" {
			hints = append(hints, styleKey.Render("x")+" explicación")
		}
	}
	hints = append(hints, styleKey.Render("q")+" back")
	return styleDim.Render(strings.Join(hints, "   "))
}

func renderVerdict(v grader.Verdict) string {
	if v.Passed() {
		return styleOK.Render("OK") + "  " + v.Summary
	}
	out := styleKO.Render("KO") + "  " + v.Summary
	if v.Detail != "" {
		out += "\n\n" + styleBox.Render(strings.TrimSpace(v.Detail))
	}
	return out
}

// clock renders a duration as h:mm:ss.
func clock(d time.Duration) string {
	if d < 0 {
		d = 0
	}
	total := int(d.Seconds())
	return fmt.Sprintf("%d:%02d:%02d", total/3600, (total/60)%60, total%60)
}

// subjectTitle is used by the practice list.
func subjectTitle(ex catalog.Exercise) string {
	return fmt.Sprintf("%-22s level %d", ex.Name, ex.Level)
}
```

- [ ] **Step 8: Run the tests to verify they pass**

Run: `go test ./internal/ui/ -v`
Expected: FAIL on the practice and result views, which Task 12 adds. The menu, exam and tick tests must pass.

- [ ] **Step 9: Commit**

```bash
git add go.mod go.sum internal/ui/
git commit -m "feat(ui): menu, exam header and exercise screen

Grading runs as a Bubble Tea command rather than inline so the countdown
keeps ticking while a compile is in flight. The exam header shows points
against the pass mark and the time left, the two numbers that actually
drive decisions during a real exam.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

