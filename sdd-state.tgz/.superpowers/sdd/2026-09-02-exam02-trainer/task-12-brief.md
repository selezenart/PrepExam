### Task 12: Practice list and result screen

**Files:**
- Create: `internal/ui/practice.go`, `internal/ui/result.go`
- Modify: `internal/ui/model_test.go` — add the tests below.

**Interfaces:**
- Consumes: `Model` from Task 11, `store.State.Weakest` from Task 8.
- Produces: `(Model).updatePractice`, `(Model).viewPractice`, `(Model).viewResult`.

- [ ] **Step 1: Write the failing tests**

Append to `internal/ui/model_test.go`:

```go
func TestPracticeShowsPerExerciseStats(t *testing.T) {
	state, _ := store.Load(t.TempDir())
	state.Record("ft_strlen", "OK", true)
	state.Record("ft_atoi", "wrong output", false)
	m := New(Deps{
		Catalog: testCatalog(t), Grader: grader.New(), Config: store.DefaultConfig(),
		State: state, StateDir: t.TempDir(), Root: t.TempDir(),
	})
	next, _ := m.Update(key("2"))
	view := next.View()
	if !strings.Contains(view, "1/1") {
		t.Errorf("the practice list does not show ft_strlen's record:\n%s", view)
	}
	if !strings.Contains(view, "0/1") {
		t.Errorf("the practice list does not show ft_atoi's record:\n%s", view)
	}
}

func TestPracticeCursorMoves(t *testing.T) {
	m := newTestModel(t)
	next, _ := m.Update(key("2"))
	down, _ := next.Update(tea.KeyMsg{Type: tea.KeyDown})
	if down.cursor != 1 {
		t.Errorf("cursor = %d after down, want 1", down.cursor)
	}
	up, _ := down.Update(tea.KeyMsg{Type: tea.KeyUp})
	if up.cursor != 0 {
		t.Errorf("cursor = %d after up, want 0", up.cursor)
	}
	// The cursor must not run off the top of the list.
	again, _ := up.Update(tea.KeyMsg{Type: tea.KeyUp})
	if again.cursor != 0 {
		t.Errorf("cursor = %d at the top, want it to stay at 0", again.cursor)
	}
}

func TestPracticeDrillPicksTheWeakest(t *testing.T) {
	state, _ := store.Load(t.TempDir())
	// Everything attempted once, ft_split failed the most.
	state.Record("ft_strlen", "OK", true)
	state.Record("ft_atoi", "OK", true)
	state.Record("epur_str", "OK", true)
	state.Record("ft_split", "wrong output", false)
	state.Record("ft_split", "wrong output", false)
	m := New(Deps{
		Catalog: testCatalog(t), Grader: grader.New(), Config: store.DefaultConfig(),
		State: state, StateDir: t.TempDir(), Root: t.TempDir(),
	})
	list, _ := m.Update(key("2"))
	drill, _ := list.Update(key("w"))
	if drill.current.Name != "ft_split" {
		t.Errorf("drill chose %q, want ft_split, the most failed", drill.current.Name)
	}
}

func TestResultScreenStatesPassOrFail(t *testing.T) {
	m := newTestModel(t)
	exam, _ := m.Update(key("1"))
	exam.screen = screenResult
	view := exam.View()
	if !strings.Contains(view, "0 / 100") {
		t.Errorf("the result screen does not show the score:\n%s", view)
	}
	if !strings.Contains(strings.ToLower(view), "fail") {
		t.Errorf("the result screen does not state the outcome:\n%s", view)
	}
}
```

- [ ] **Step 2: Run them to verify they fail**

Run: `go test ./internal/ui/ -run 'TestPractice|TestResult' -v`
Expected: FAIL — `undefined: (Model).updatePractice`.

- [ ] **Step 3: Write the practice screen**

Create `internal/ui/practice.go`:

```go
package ui

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
)

func (m Model) updatePractice(msg tea.KeyMsg) (Model, tea.Cmd) {
	switch msg.String() {
	case "ctrl+c":
		return m, tea.Quit

	case "q", "esc":
		m.screen = screenMenu
		return m, nil

	case "up", "k":
		if m.cursor > 0 {
			m.cursor--
		}
		return m, nil

	case "down", "j":
		if m.cursor < len(m.practice)-1 {
			m.cursor++
		}
		return m, nil

	case "enter":
		if len(m.practice) == 0 {
			return m, nil
		}
		m.current = m.practice[m.cursor]
		m.screen = screenExercise
		return m.loadCurrent()

	case "w":
		// Drill whichever exercise the record says is weakest.
		names := make([]string, 0, len(m.practice))
		for _, ex := range m.practice {
			names = append(names, ex.Name)
		}
		weakest := m.deps.State.Weakest(names)
		ex, ok := m.deps.Catalog.ByName(weakest)
		if !ok {
			return m, nil
		}
		m.current = ex
		m.screen = screenExercise
		return m.loadCurrent()
	}
	return m, nil
}

func (m Model) viewPractice() string {
	var b strings.Builder
	b.WriteString(styleTitle.Render("Practice") + "\n\n")

	for i, ex := range m.practice {
		marker := "  "
		if i == m.cursor {
			marker = styleKey.Render("> ")
		}
		record := styleDim.Render("     —")
		if st, ok := m.deps.State.Exercises[ex.Name]; ok && st.Attempts > 0 {
			text := fmt.Sprintf("%5s", fmt.Sprintf("%d/%d", st.Passes, st.Attempts))
			if st.Passes > 0 {
				record = styleOK.Render(text)
			} else {
				record = styleKO.Render(text)
			}
		}
		b.WriteString(marker + subjectTitle(ex) + "  " + record + "\n")
	}

	b.WriteString("\n" + styleDim.Render(
		styleKey.Render("enter")+" open   "+
			styleKey.Render("w")+" drill weakest   "+
			styleKey.Render("q")+" back"))
	return b.String()
}
```

- [ ] **Step 4: Write the result screen**

Create `internal/ui/result.go`:

```go
package ui

import (
	"fmt"
	"strings"
)

func (m Model) viewResult() string {
	var b strings.Builder
	if m.exam == nil {
		return "no exam to report on"
	}

	points, mark := m.exam.Points(), m.deps.Config.PassMark
	headline := styleKO.Render("FAILED")
	if m.exam.Passed() {
		headline = styleOK.Render("PASSED")
	}
	b.WriteString(styleTitle.Render("Exam over") + "   " + headline + "\n\n")
	b.WriteString(fmt.Sprintf("%d / %d points\n", points, mark))
	b.WriteString(fmt.Sprintf("%s remaining on the clock\n\n", clock(m.exam.Remaining(m.now))))

	attempts := m.exam.Attempts()
	if len(attempts) == 0 {
		b.WriteString(styleDim.Render("nothing was submitted") + "\n")
	} else {
		b.WriteString(styleDim.Render("attempts") + "\n")
		for _, a := range attempts {
			outcome := styleKO.Render("KO")
			if a.Passed {
				outcome = styleOK.Render("OK")
			}
			b.WriteString(fmt.Sprintf("  %s  level %d  %s\n", outcome, a.Level, a.Exercise))
		}
	}

	if !m.exam.Passed() {
		b.WriteString("\n" + styleDim.Render(
			"The pass mark is every level cleared. Practice mode has no clock.") + "\n")
	}
	b.WriteString("\n" + styleDim.Render(
		styleKey.Render("q")+" quit   any other key returns to the menu"))
	return b.String()
}
```

- [ ] **Step 5: Write the failing resume test**

Append to `internal/ui/model_test.go`:

```go
func TestMenuOffersResumeOnlyWhenAnExamIsInFlight(t *testing.T) {
	m := newTestModel(t)
	if strings.Contains(m.View(), "Resume") {
		t.Errorf("the menu offers Resume with no exam in flight:\n%s", m.View())
	}

	pools := map[int][]string{1: {"ft_strlen"}, 2: {"ft_atoi"}, 3: {"epur_str"}, 4: {"ft_split"}}
	exam, err := session.NewExam(store.DefaultConfig(), pools, rand.New(rand.NewSource(1)), time.Now())
	if err != nil {
		t.Fatalf("NewExam() error = %v", err)
	}
	state, _ := store.Load(t.TempDir())
	withExam := New(Deps{
		Catalog: testCatalog(t), Grader: grader.New(), Config: store.DefaultConfig(),
		State: state, StateDir: t.TempDir(), Root: t.TempDir(), ResumeExam: exam,
	})
	if !strings.Contains(withExam.View(), "Resume") {
		t.Errorf("the menu does not offer Resume for an exam in flight:\n%s", withExam.View())
	}
}

func TestResumingReturnsToTheExamInProgress(t *testing.T) {
	pools := map[int][]string{1: {"ft_strlen"}, 2: {"ft_atoi"}, 3: {"epur_str"}, 4: {"ft_split"}}
	exam, err := session.NewExam(store.DefaultConfig(), pools, rand.New(rand.NewSource(1)), time.Now())
	if err != nil {
		t.Fatalf("NewExam() error = %v", err)
	}
	exam.Record(true, time.Now()) // already cleared level 1
	state, _ := store.Load(t.TempDir())
	m := New(Deps{
		Catalog: testCatalog(t), Grader: grader.New(), Config: store.DefaultConfig(),
		State: state, StateDir: t.TempDir(), Root: t.TempDir(), ResumeExam: exam,
	})
	next, _ := m.Update(key("c"))
	view := next.View()
	if !strings.Contains(view, "Level 2") {
		t.Errorf("resuming did not return to level 2:\n%s", view)
	}
	if !strings.Contains(view, "25 / 100") {
		t.Errorf("resuming lost the score:\n%s", view)
	}
}
```

The test file now needs `math/rand` and `exam02/internal/session` in its imports.

- [ ] **Step 6: Wire resume through the model**

In `internal/ui/model.go`, add the field to `Deps`:

```go
	// ResumeExam is an exam recovered from saved state, or nil when there is
	// none in flight.
	ResumeExam *session.Exam
```

Make `New` adopt it:

```go
// New builds the initial model, showing the menu.
func New(deps Deps) Model {
	return Model{deps: deps, screen: screenMenu, now: time.Now(), exam: deps.ResumeExam}
}
```

Add a method that persists the exam after every change, so a crash loses at
most the current attempt:

```go
// persistExam writes the in-flight exam into saved state. A finished exam is
// cleared instead, so the menu does not offer to resume a run that is over.
func (m *Model) persistExam() {
	if m.exam == nil || m.exam.Over(time.Now()) {
		m.deps.State.Exam = nil
	} else {
		raw, err := session.Encode(m.exam)
		if err != nil {
			m.err = err
			return
		}
		m.deps.State.Exam = raw
	}
	if err := m.deps.State.Save(m.deps.StateDir); err != nil {
		m.err = err
	}
}
```

Call it at the end of `startExam` (after `loadCurrent`) and in `applyVerdict`
immediately after `m.exam.Record(...)`.

- [ ] **Step 7: Add the menu entry**

In `internal/ui/menu.go`, handle the key in `updateMenu`:

```go
	case "c":
		if m.exam != nil && !m.exam.Over(time.Now()) {
			m.screen = screenExam
			return m.loadCurrent()
		}
		return m, nil
```

And render it in `viewMenu`, after the Practice line:

```go
	if m.exam != nil && !m.exam.Over(m.now) {
		b.WriteString(styleKey.Render("c") + "  Resume      " +
			styleWarn.Render(fmt.Sprintf("exam in progress, %s left", clock(m.exam.Remaining(m.now)))) + "\n")
	}
```

- [ ] **Step 8: Run the whole UI suite**

Run: `go test ./internal/ui/ -v`
Expected: PASS, every test including those from Task 11.

- [ ] **Step 9: Commit**

```bash
git add internal/ui/
git commit -m "feat(ui): practice list, result screen, and resuming an exam

The practice list carries each exercise's pass record so the weakest are
visible, and w jumps straight to whichever the record says is weakest.
The result screen states pass or fail against the 100 point mark rather
than only reporting the level reached.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

