### Task 17: Level 4 content

The hardest set: two more linked-list exercises, one taking a function pointer,
one taking a struct.

**Files:**
- Modify: `meta.yaml` in all 10 Level 4 exercise directories
- Create: `driver.c` in the 7 function-kind directories
- Create: `cases.txt` in all 10 directories

**Interfaces:**
- Consumes: Tasks 2, 6, 7.
- Produces: 10 gradable exercises, so `GradableByLevel(4)` is no longer empty
  and exam mode can run a complete four-level session.

- [ ] **Step 1: Confirm every meta.yaml**

| Exercise | kind | prototype | allowed_functions | header |
| --- | --- | --- | --- | --- |
| flood_fill | function | `void flood_fill(char **tab, t_point size, t_point begin);` | none | flood_fill.h |
| fprime | program | — | printf, atoi | — |
| ft_itoa | function | `char *ft_itoa(int nbr);` | malloc | — |
| ft_list_foreach | function | `void ft_list_foreach(t_list *begin_list, void (*f)(void *));` | none | ft_list.h |
| ft_list_remove_if | function | `void ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)());` | free | ft_list.h |
| ft_split | function | `char **ft_split(char *str);` | malloc | — |
| rev_wstr | program | — | write, malloc, free | — |
| rostring | program | — | write, malloc, free | — |
| sort_int_tab | function | `void sort_int_tab(int *tab, unsigned int size);` | none | — |
| sort_list | function | `t_list *sort_list(t_list* lst, int (*cmp)(int, int));` | none | list.h |

`flood_fill` is one of only two subjects whose expected files are the glob
`*.c, *.h` (the other is `do_op`, in Level 2), so its `expected_file` cannot be
parsed and must read `flood_fill.c`. Confirm the importer's fallback produced
that. Every other Level 4 exercise names its `.c` explicitly.

- [ ] **Step 2: Write the seven drivers**

`ft_split` returns a NULL-terminated array, so print one word per line with an
end marker — without it, a split that returns an empty array and one that
returns nothing look identical:

```c
#include <stdio.h>

char	**ft_split(char *str);

int	main(int argc, char **argv)
{
	char	**words;
	int		i;

	if (argc < 2)
		return (1);
	words = ft_split(argv[1]);
	if (!words)
	{
		printf("(null)\n");
		return (0);
	}
	i = 0;
	while (words[i])
	{
		printf("[%s]\n", words[i]);
		i++;
	}
	printf("count=%d\n", i);
	return (0);
}
```

`ft_list_foreach` takes a function pointer, so the driver supplies one that
prints what it is given, making the traversal order observable:

```c
#include <stdio.h>
#include <stdlib.h>
#include "ft_list.h"

void	ft_list_foreach(t_list *begin_list, void (*f)(void *));

void	print_data(void *data)
{
	printf("[%s]\n", (char *)data);
}

int	main(int argc, char **argv)
{
	t_list	*head;
	t_list	*node;
	int		i;

	head = NULL;
	i = argc - 1;
	while (i >= 1)
	{
		node = malloc(sizeof(t_list));
		node->data = argv[i];
		node->next = head;
		head = node;
		i--;
	}
	ft_list_foreach(head, &print_data);
	printf("|end\n");
	return (0);
}
```

`flood_fill` mutates the grid in place, so the driver builds the grid from
argv, calls the function, and prints every row afterwards. Read
`flood_fill.h` for the exact shape of `t_point` before writing it.

`ft_list_remove_if` needs a `cmp` the driver supplies, and must print the list
after removal. `sort_list` needs a `cmp` taking two ints. Check each
exercise's own header for its struct's field names — they are not identical
across the three list exercises.

- [ ] **Step 3: Write a case file for each of the 10**

As Task 15's step 3. For `ft_split` include repeated separators, leading and
trailing separators, tabs and newlines as separators, a string of only
separators, and the empty string. For `ft_itoa` include 0, a negative number,
and `INT_MIN`, which is the boundary that breaks most implementations and which
the subject does define.

- [ ] **Step 4: Run the suite**

Run: `go test ./internal/grader/ -run 'TestEveryReference|TestMutated' -v`
Expected: green across all 56 exercises. `readyExercises` should now return 56.

- [ ] **Step 5: Confirm every level is drawable**

Add to `internal/catalog/load_test.go`:

```go
func TestEveryLevelHasGradableExercises(t *testing.T) {
	// An exam draws one exercise per level. A level with nothing gradable
	// would make exam mode refuse to start.
	c, err := Embedded()
	if err != nil {
		t.Fatalf("Embedded() error = %v", err)
	}
	for level := 1; level <= 4; level++ {
		if n := len(c.GradableByLevel(level)); n == 0 {
			t.Errorf("level %d has no gradable exercises; exam mode cannot start", level)
		}
	}
	if n := len(c.All()); n != 56 {
		t.Errorf("All() = %d exercises, want 56", n)
	}
}
```

Run: `go test ./internal/catalog/ -v`
Expected: PASS.

- [ ] **Step 6: Run everything**

Run: `go test ./...`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add internal/catalog/
git commit -m "feat(data): Level 4 drivers and cases complete all 56 exercises

Every level now has gradable exercises, so an exam can run a full four
level session. The new catalog test fails if any level empties out,
which would silently make exam mode refuse to start.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```
