# SDD ledger — plan: docs/superpowers/plans/2026-09-02-exam02-trainer.md

Branch: feat/trainer (created from main; main holds docs only)
Spec: docs/superpowers/specs/2026-09-02-exam02-trainer-design.md (read, binding authority)

## Pre-flight conflict scan

### Cross-task rows (tasks sharing a file or interface)

| Producer → Consumer | Interface | Finding |
|---|---|---|
| T1 → T3 | `catalog.ParseSubject(string) (SubjectMeta, error)` | agrees |
| T2 → T3 | `catalog.Meta` yaml tags marshalled by importer | agrees |
| T2 → T6 | `catalog.Exercise` fields Kind/AllowedFunctions/Reference/Driver/Cases/Timeout() | agrees |
| T2 → T7 | `Load(fs.FS)`; embed.go joins same package | agrees |
| T4 → T6 | `sandbox.Run(ctx,bin,args,stdin,timeout) (Result,error)`; Result fields | agrees |
| T5 → T6 | `objectSymbols`/`Forbidden`/`DefinesMain`, same package | agrees |
| T5 → T6 | `contains` helper defined in symbols_test.go, used there only | agrees (grade_test.go now uses strings.Contains) |
| T3 → T7 | importer default `-dst` changed when data moves under internal/catalog | agrees (T7 step 4 says so) |
| T8 → T9 | `store.Config{ExamDuration,PointsPerExercise,PassMark}` | agrees |
| T8 → T11/12/13 | `store.State.{Exercises,Record,Weakest,Save,Exam}`, `store.Dir` | agrees |
| T9 → T11/12/13 | `session.NewExam/Encode/Decode/Attach` + Exam methods | agrees |
| T10 → T11 | `workspace.Prepare`, `workspace.EditorCommand` | agrees |
| **T11 → T12** | `model.go View()` calls `viewPractice`/`viewResult`; `handleKey` calls `updatePractice` | **CONFLICT — see F1** |
| T12 → T13 | `ui.Deps.ResumeExam` | agrees |
| T13 → T7 | `catalog.Embedded()` | agrees |
| T14 | no code dependencies | agrees |

### Per-task self-agreement rows

| Task | Own tests vs own code, files created vs later touched | Finding |
|---|---|---|
| T1 | 5 subject spellings tested, all handled by parser | agrees |
| T2 | **`TestLoadRejectsFunctionExerciseWithoutDriver` vs the post-import repo state** | **CONFLICT — see F2** |
| T3 | importer writes no cases.txt/driver.c for any of the 56 | feeds F2 |
| T4 | 7 tests incl. process-group kill; code sets Setpgid | agrees |
| T5 | fixture tests compile real C; allowlist per GOOS | agrees |
| T6 | pipeline stages match Verdict statuses one-for-one | agrees |
| T7 | suite filters `len(ex.Cases) > 0`; needs Load to tolerate absence | feeds F2 |
| T8 | atomic save, corrupt-state recovery, Weakest ordering | agrees |
| T9 | state machine + Encode/Decode; `Attach` now used by Decode | agrees |
| T10 | never-overwrite is asserted | agrees |
| T11 | see F1 | — |
| T12 | resume steps reference `session`, `math/rand` in test imports (called out in step 5) | agrees |
| T13 | `resumableExam` builds pools from `ByLevel` | **CONFLICT — see F3** |
| T14 | Makefile/README only | agrees |

### Findings and rulings

**F1 — Task 11 cannot compile on its own.** `model.go` (T11) routes to
`viewPractice`, `viewResult` and `updatePractice`, which T12 creates. T11's
step 8 admits "tests fail" but the tree would not even build, so T11 could
not honestly commit.

Ruling: dispatch Tasks 11 and 12 to ONE implementer as a single unit and
review the combined diff. They are the same package and the split has no
independent review surface. Chosen over stubbing the three functions in T11,
which would plant placeholders the plan's own rules forbid.
Cost if wrong: a larger UI review surface, so a fix loop there works over a
bigger diff.

**F2 — the catalog will refuse to load after the importer runs.** T3 generates
all 56 exercise directories with neither `cases.txt` nor `driver.c`. T2's
`loadExercise` treats both as load errors, so `catalog.Embedded()` would fail
outright and the application would not start with Levels 2-4 present. T7's
suite already assumes the opposite — it filters on `len(ex.Cases) > 0`,
which only makes sense if a caseless exercise loads.

Ruling: an exercise with neither cases nor driver is *not yet authored* and
loads as non-gradable, not as an error. An exercise with cases but no driver
(function kind) stays an error — that is a half-finished author's mistake and
must not pass silently. Add `Exercise.Gradable()` and
`Catalog.GradableByLevel(int)`; practice lists everything, exams draw only
from gradable pools.
Cost if wrong: a genuinely corrupt exercise directory loads quietly as
non-gradable instead of failing loudly at startup.

**F3 — exam mode would be unusable on delivery.** Following from F2, exam
pools built from Level 1 content alone leave levels 2-4 empty, and
`session.NewExam` correctly refuses. The user gave me the exam's real scoring
rules specifically to have exam mode; shipping with it disabled is not the
thing they asked for.

Ruling: promote the Levels 2-4 content from a follow-on plan into this run as
Tasks 15, 16 and 17, executed immediately after Task 7 and before the UI
tasks, so every later task can exercise a fully working exam. Task 13's
`resumableExam` and the UI's exam pools use `GradableByLevel`.
Cost if wrong: a materially longer run than the plan I got approval for. The
alternative — delivering a trainer whose exam mode cannot start — is worse.

Execution order: 1, 2, 3, 4, 5, 6, 7, 15, 16, 17, 8, 9, 10, 11+12, 13, 14.

## Task log

Briefs generated for all 17 tasks.
Task 1: dispatched (haiku — plan carries complete code, transcription + TDD), BASE=4cfbba4
Ruling F3 confirmed by the user directly ("yes do all 56, keep going") — Levels 2-4
are in scope for this run, not deferred. No longer a provisional ruling.
Task 1: implemented 2cefb7b, 9/9 tests, TDD evidence present. Review dispatched (sonnet).
Prereq check (controller, read-only): cross-compile OK for darwin/arm64, darwin/amd64,
linux/amd64, linux/arm64 from this Linux host; /usr/bin/nm present; go vet clean.
Task 14's "no Mac needed" and Task 5's nm dependency both verified before relying on them.
Task 1: review clean (spec compliant, quality Approved, 0 Critical, 0 Important).
  Reviewer's one ⚠️ (commit trailer not visible in diff payload) resolved by controller:
  trailer verified present on 2cefb7b.
Task 1: minor (deferred): subject.go:83 EqualFold accepts any casing of "None", broader
  than the brief's literal spelling. Harmless leniency; carry to final review triage.
Task 1: complete (commits 4cfbba4..2cefb7b, review clean)
Task 2: dispatched (sonnet — F2 tolerance logic is subtle and load-bearing downstream,
  not worth the cheapest tier), BASE=2cefb7b
Task 2: review clean (spec compliant, Approved, 0 Critical, 0 Important). Reviewer verified
  all three F2 tolerance rules by reading code, not just tests: driver read precedes the
  cases check (load.go:295 before :312), program-kind with cases and no driver is not an
  error, unauthored path returns a populated Exercise rather than a zero value, and
  {"args":[]} vs {"args":[""]} stay distinct. ⚠️ trailer resolved by controller: present.
Task 2: minor (deferred): no Load()-level test for a malformed cases.txt (only ParseCases
  direct); map-order nondeterminism in which missing required file is named first.
Task 2: complete (commits 2cefb7b..6751c25, review clean)
Task 3: dispatched (sonnet — code is complete in brief but it runs a generator over 56
  directories and hand-edits 12 meta.yaml files), BASE=6751c25
Task 3: implementer correctly challenged the brief. I had written that FOUR subjects use a
  glob expected_file; only TWO do (do_op, flood_fill). The other two multi-file entries
  (ft_list_size, ft_list_foreach) name their .c explicitly.
  Ruling: implementer is right, my plan and spec were wrong. Corrected both, and fixed
  Task 17's table which wrongly named sort_list as a glob subject and would have sent that
  implementer looking for a problem that does not exist. Task 15's table now flags do_op.
  Briefs 15 and 17 regenerated. Cost if wrong: none — verified directly against upstream.
  Deferred minor: tools/import/main.go carries the same inaccurate "four" doc comment in
  shipped code; hand to the final review fix wave.
Controller-verified for Task 3 (mechanical, stronger than review-by-eye): all 56 subject.md
  and reference.c byte-identical to upstream; per-level 12/19/15/10; 5 headers; Level 1
  kinds match the table exactly; both glob subjects got correct fallback expected_file.
Task 3: review clean (spec compliant, Approved, 0 Critical, 0 Important). Reviewer traced
  the REVIEW-line mechanism and proved it exhaustive over both guessed fields (no exercise
  can be guessed without being flagged), and confirmed singleFileWithSuffix fails the whole
  run rather than silently baking an arbitrary .c in as reference.c.
Task 3: minor (deferred): stale "four subjects" glob count in tools/import/main.go package
  comment. Docs already corrected; the code comment goes to the final review fix wave.
Task 3: complete (commits 6751c25..47df56c, review clean)
Task 4: dispatched (haiku — brief carries complete code, pure transcription + TDD), BASE=47df56c
Task 4: implemented 874548c, 7/7 tests. TWO controller observations before review:
  (a) Deviation from brief: the ctx.Done() path now waits up to 200ms for the process to
      finish before killing the group (run.go:66). Brief killed immediately. Consequence a
      grading tool cares about: a program overrunning its deadline by <200ms is reported as
      a normal exit, not TimedOut. Named neutrally for the reviewer to judge, not pre-judged.
  (b) Cost signal: haiku took 82 tool calls / 11 minutes on a pure-transcription task.
      Ruling: stop using haiku for these; sonnet is the floor for remaining implementers.
      Cost if wrong: slightly higher per-task token price, offset by far fewer turns.
Task 4: review dispatched (sonnet)
Task 4: review verdict SPEC ❌ / Needs fixes. 2 Important + 1 Minor.
  Reviewer independently confirmed the grace period is what makes TestRunReportsSignal pass
  on this box (1.06s > its 1s timeout is only explainable if the deadline fired and the real
  signal arrived ~60ms into the grace), i.e. production semantics were bent to fix a flaky
  test. Also confirmed TestRunTimeoutKillsGrandchildren is a genuine capability test: the
  inherited stdout pipe stays open while the grandchild lives, so a broken group-kill really
  would hang it for ~30s.
  My independent read agrees; the finding stands. Fix round 1/5: resumed original implementer
  with findings verbatim. Invariant stated as non-negotiable: deadline crossed => TimedOut true.
  FIX_BASE=874548c
Task 4: fix round 1/5 (5 addressed, 0 open — grace period deleted outright, TimedOut now
  unconditional on the deadline path, signal test given 2s headroom; commits 874548c..ef97356)
  Re-reviewer confirmed Run is byte-identical to the brief again, the group-kill guarantee is
  intact (grandchild test dropped 0.40s -> 0.20s, exactly the base timeout, proving the grace
  window is gone), and the test would still catch a broken group kill.
  Residual Minor (pre-existing in kind, from the brief's own test style): TestRunReportsSignal
  still uses a fixed wall-clock budget, so apport latency could in principle exceed 2s under
  heavy load. Mitigated 2x, not eliminated. Deferred to final review.
  Controller error noted: ef97356 also carries my uncommitted plan doc-correction, swept in by
  the implementer's git add. My fault for leaving controller edits in the working tree.
  Corrective: commit controller doc edits immediately, before dispatching. Not rewriting
  history over it — content is correct, only the commit label is broader than it claims.
Task 4: complete (commits 47df56c..ef97356, review clean after 1 fix round)
Task 5: dispatched (sonnet per the model ruling), BASE=ef97356
