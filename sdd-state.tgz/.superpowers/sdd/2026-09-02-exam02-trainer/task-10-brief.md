### Task 10: Workspace preparation and the editor

**Files:**
- Create: `internal/workspace/workspace.go`
- Test: `internal/workspace/workspace_test.go`

**Interfaces:**
- Consumes: `catalog.Exercise` (Task 2).
- Produces: `workspace.Prepare(root string, ex catalog.Exercise) (string, error)`, `workspace.EditorCommand(path string) *exec.Cmd`.

- [ ] **Step 1: Write the failing test**

Create `internal/workspace/workspace_test.go`:

```go
package workspace

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"exam02/internal/catalog"
)

func strlenExercise() catalog.Exercise {
	return catalog.Exercise{
		Meta: catalog.Meta{
			Name: "ft_strlen", Level: 1, Kind: catalog.KindFunction,
			ExpectedFile: "ft_strlen.c", Prototype: "int ft_strlen(char *str);",
		},
	}
}

func TestPrepareCreatesTheFile(t *testing.T) {
	root := t.TempDir()
	path, err := Prepare(root, strlenExercise())
	if err != nil {
		t.Fatalf("Prepare() error = %v", err)
	}
	if want := filepath.Join(root, "rendu", "ft_strlen", "ft_strlen.c"); path != want {
		t.Errorf("path = %q, want %q", path, want)
	}
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("reading the prepared file: %v", err)
	}
	if !strings.Contains(string(body), "int ft_strlen(char *str);") {
		t.Errorf("prepared file does not carry the prototype:\n%s", body)
	}
}

func TestPrepareNeverOverwritesExistingWork(t *testing.T) {
	// The candidate's work is sacred. Re-entering an exercise must not wipe it.
	root := t.TempDir()
	path, err := Prepare(root, strlenExercise())
	if err != nil {
		t.Fatalf("Prepare() error = %v", err)
	}
	if err := os.WriteFile(path, []byte("my hard work"), 0o644); err != nil {
		t.Fatal(err)
	}
	if _, err := Prepare(root, strlenExercise()); err != nil {
		t.Fatalf("Prepare() error = %v", err)
	}
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if string(body) != "my hard work" {
		t.Errorf("file = %q, want the candidate's work untouched", body)
	}
}

func TestPrepareWritesTheProvidedHeader(t *testing.T) {
	root := t.TempDir()
	ex := strlenExercise()
	ex.Header = "ft_list.h"
	ex.HeaderContent = "typedef struct s_list t_list;\n"
	if _, err := Prepare(root, ex); err != nil {
		t.Fatalf("Prepare() error = %v", err)
	}
	body, err := os.ReadFile(filepath.Join(root, "rendu", "ft_strlen", "ft_list.h"))
	if err != nil {
		t.Fatalf("the provided header was not written: %v", err)
	}
	if string(body) != ex.HeaderContent {
		t.Errorf("header = %q, want %q", body, ex.HeaderContent)
	}
}

func TestPrepareProgramKindHasNoPrototypeStub(t *testing.T) {
	root := t.TempDir()
	ex := strlenExercise()
	ex.Kind = catalog.KindProgram
	ex.Prototype = ""
	ex.Name = "rot_13"
	ex.ExpectedFile = "rot_13.c"
	path, err := Prepare(root, ex)
	if err != nil {
		t.Fatalf("Prepare() error = %v", err)
	}
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(body), "int main(int argc, char **argv)") {
		t.Errorf("a program exercise should be seeded with a main:\n%s", body)
	}
}

func TestEditorCommandHonoursTheEnvironment(t *testing.T) {
	t.Setenv("EDITOR", "nano")
	cmd := EditorCommand("/tmp/x.c")
	if cmd.Args[0] != "nano" {
		t.Errorf("editor = %q, want nano", cmd.Args[0])
	}
	t.Setenv("EDITOR", "")
	if cmd := EditorCommand("/tmp/x.c"); cmd.Args[0] != "vim" {
		t.Errorf("editor = %q, want the vim default", cmd.Args[0])
	}
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/workspace/ -v`
Expected: FAIL — `undefined: Prepare`.

- [ ] **Step 3: Write the implementation**

Create `internal/workspace/workspace.go`:

```go
// Package workspace prepares the directory a candidate writes their answer in.
//
// The layout mirrors the real exam: rendu/<exercise>/<file>.c under the
// working directory.
package workspace

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"

	"exam02/internal/catalog"
)

// Prepare creates the exercise's directory and seeds its source file, and
// returns the path to that file.
//
// An existing file is left exactly as it is. Re-entering an exercise must
// never destroy work, so seeding only ever happens once.
func Prepare(root string, ex catalog.Exercise) (string, error) {
	dir := filepath.Join(root, "rendu", ex.Name)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", fmt.Errorf("creating %s: %w", dir, err)
	}

	if ex.Header != "" {
		headerPath := filepath.Join(dir, ex.Header)
		if _, err := os.Stat(headerPath); os.IsNotExist(err) {
			if err := os.WriteFile(headerPath, []byte(ex.HeaderContent), 0o644); err != nil {
				return "", fmt.Errorf("writing %s: %w", ex.Header, err)
			}
		}
	}

	path := filepath.Join(dir, ex.ExpectedFile)
	if _, err := os.Stat(path); err == nil {
		return path, nil
	}
	if err := os.WriteFile(path, []byte(stub(ex)), 0o644); err != nil {
		return "", fmt.Errorf("writing %s: %w", ex.ExpectedFile, err)
	}
	return path, nil
}

// stub is the starting content of a fresh answer file: enough to compile
// against, never enough to be a hint.
func stub(ex catalog.Exercise) string {
	header := fmt.Sprintf("/* %s */\n\n", ex.Name)
	if ex.Kind == catalog.KindProgram {
		return header + "int\tmain(int argc, char **argv)\n{\n\t(void)argc;\n\t(void)argv;\n\treturn (0);\n}\n"
	}
	if ex.Prototype == "" {
		return header
	}
	// Turn the declaration into an empty definition the candidate fills in.
	body := ex.Prototype
	if body[len(body)-1] == ';' {
		body = body[:len(body)-1]
	}
	return header + body + "\n{\n}\n"
}

// EditorCommand builds the command that opens path in the candidate's editor.
func EditorCommand(path string) *exec.Cmd {
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vim"
	}
	cmd := exec.Command(editor, path)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	return cmd
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `go test ./internal/workspace/ -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add internal/workspace/
git commit -m "feat(workspace): seed rendu/ the way the real exam lays it out

Seeding happens once and only once: an existing answer file is never
rewritten, so re-entering an exercise cannot destroy work in progress.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

