### Task 15: Level 2 content

Same shape as Task 7, for the 19 Level 2 exercises. The engine does not change;
if it turns out it must, stop and design the change rather than bending a
driver around it.

**Files:**
- Modify: `meta.yaml` in all 19 Level 2 exercise directories
- Create: `driver.c` in the 12 function-kind directories
- Create: `cases.txt` in all 19 directories

**Interfaces:**
- Consumes: `catalog.Exercise`, the grader, and the suite from Tasks 2, 6 and 7.
- Produces: 19 gradable exercises, so `GradableByLevel(2)` is no longer empty.

- [ ] **Step 1: Confirm every meta.yaml**

The importer guessed `kind`. These are the correct values, read from the
subjects. Note that ten exercises across levels 2 to 4 write "prototyped as
follows" rather than "declared as follows", so the importer's heuristic marks
them uncertain — every one of those is a function.

| Exercise | kind | prototype | allowed_functions |
| --- | --- | --- | --- |
| alpha_mirror | program | — | write |
| camel_to_snake | program | — | malloc, realloc, write |
| do_op | program | — | atoi, printf, write | *(glob subject: `expected_file` is not parseable and must read `do_op.c`)* |
| ft_atoi | function | `int ft_atoi(const char *str);` | none |
| ft_strcmp | function | `int ft_strcmp(char *s1, char *s2);` | none |
| ft_strcspn | function | `size_t ft_strcspn(const char *s, const char *reject);` | none |
| ft_strdup | function | `char *ft_strdup(char *src);` | malloc |
| ft_strpbrk | function | `char *ft_strpbrk(const char *s1, const char *s2);` | none |
| ft_strrev | function | `char *ft_strrev(char *str);` | none |
| ft_strspn | function | `size_t ft_strspn(const char *s, const char *accept);` | none |
| is_power_of_2 | function | `int is_power_of_2(unsigned int n);` | none |
| last_word | program | — | write |
| max | function | `int max(int* tab, unsigned int len);` | none |
| print_bits | function | `void print_bits(unsigned char octet);` | write |
| reverse_bits | function | `unsigned char reverse_bits(unsigned char octet);` | none |
| snake_to_camel | program | — | malloc, free, realloc, write |
| swap_bits | function | `unsigned char swap_bits(unsigned char octet);` | none |
| union | program | — | write |
| wdmatch | program | — | write |

- [ ] **Step 2: Write a driver for each of the 12 function exercises**

A driver supplies `main`, calls the candidate's function on arguments taken
from argv, and prints the result so a wrong answer differs as text. Drivers may
use `printf` freely: they are our code, compiled separately, and never subject
to the allowed-functions check.

`ft_strdup` returns freshly allocated memory, so print the contents and confirm
the result is not the input pointer — a "duplicate" that returns its argument
would otherwise pass:

```c
#include <stdio.h>

char	*ft_strdup(char *src);

int	main(int argc, char **argv)
{
	char	*copy;

	if (argc < 2)
		return (1);
	copy = ft_strdup(argv[1]);
	if (!copy)
	{
		printf("(null)\n");
		return (0);
	}
	printf("[%s]\n", copy);
	printf("is_a_copy=%d\n", copy != argv[1]);
	return (0);
}
```

`max` takes an array and a length, so the driver builds the array from the
remaining arguments:

```c
#include <stdio.h>
#include <stdlib.h>

int	max(int *tab, unsigned int len);

int	main(int argc, char **argv)
{
	int		tab[256];
	int		i;

	i = 0;
	while (i < argc - 1 && i < 256)
	{
		tab[i] = atoi(argv[i + 1]);
		i++;
	}
	printf("%d\n", max(tab, (unsigned int)i));
	return (0);
}
```

Note that `max` is specified to return 0 for a length of zero, so a case with
no arguments belongs in its case file.

`ft_strcspn` and `ft_strspn` return `size_t`, so print with `%zu`.
`print_bits` writes directly and needs an end marker after it, exactly as
`ft_putstr`'s driver in Task 7 does. `reverse_bits` and `swap_bits` take an
`unsigned char`, so convert with `atoi` and cast.

- [ ] **Step 3: Write a case file for each of the 19**

Every case file covers, where the subject gives them meaning: the empty string,
a single character, the ordinary case, the boundary the subject names, and the
wrong argument counts. "If the number of arguments is not N, display a newline"
is the rule candidates forget most, so every program exercise gets a case with
too few arguments and one with too many.

Avoid inputs whose correct behaviour the subject does not define — `ft_atoi` on
something that overflows `int` is undefined, so the reference's answer there is
arbitrary rather than authoritative, and a case built on it would fail correct
solutions.

- [ ] **Step 4: Run the suite**

Run: `go test ./internal/grader/ -run 'TestEveryReference|TestMutated' -v`

Expected on the first run: failures. Work through them exactly as in Task 7 —
a failing reference means the driver or the metadata is wrong; a mutated
reference that still passes means the cases do not reach the mutated path.
Iterate until both are green across all 31 ready exercises.

- [ ] **Step 5: Run everything**

Run: `go test ./...`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add internal/catalog/exercises/
git commit -m "feat(data): Level 2 drivers, cases and confirmed metadata

Twelve of the nineteen are function exercises, including the ten across
levels 2 to 4 whose subjects say prototyped rather than declared and so
came back from the importer marked uncertain.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

