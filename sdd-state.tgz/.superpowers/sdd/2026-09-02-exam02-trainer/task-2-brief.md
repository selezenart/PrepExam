### Task 2: Exercise types, case files, and the embedded loader

**Files:**
- Create: `internal/catalog/exercise.go`, `internal/catalog/cases.go`, `internal/catalog/load.go`
- Test: `internal/catalog/cases_test.go`, `internal/catalog/load_test.go`

**Interfaces:**
- Consumes: `catalog.SubjectMeta` from Task 1.
- Produces: `catalog.Kind`, `catalog.Exercise`, `catalog.Case`, `catalog.ParseCases(string) ([]Case, error)`, `catalog.Load(fs.FS) (*Catalog, error)`, `(*Catalog).All() []Exercise`, `(*Catalog).ByLevel(int) []Exercise`, `(*Catalog).ByName(string) (Exercise, bool)`.

- [ ] **Step 1: Write the failing case-parser test**

Create `internal/catalog/cases_test.go`:

```go
package catalog

import (
	"reflect"
	"testing"
)

func TestParseCases(t *testing.T) {
	in := `{"args": ["hello world"]}
{"args": [""]}
{"args": []}

{"args": ["a", "b"], "stdin": "x\n"}
`
	got, err := ParseCases(in)
	if err != nil {
		t.Fatalf("ParseCases() error = %v", err)
	}
	want := []Case{
		{Args: []string{"hello world"}},
		{Args: []string{""}},
		{Args: []string{}},
		{Args: []string{"a", "b"}, Stdin: "x\n"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("ParseCases() = %#v, want %#v", got, want)
	}
}

func TestParseCasesDistinguishesEmptyArgFromNoArg(t *testing.T) {
	// Several exercises print different things for ./prog "" and ./prog.
	// This distinction is the whole reason the format is JSON.
	got, err := ParseCases("{\"args\": [\"\"]}\n{\"args\": []}\n")
	if err != nil {
		t.Fatalf("ParseCases() error = %v", err)
	}
	if len(got[0].Args) != 1 || got[0].Args[0] != "" {
		t.Errorf("first case Args = %#v, want one empty string", got[0].Args)
	}
	if len(got[1].Args) != 0 {
		t.Errorf("second case Args = %#v, want none", got[1].Args)
	}
}

func TestParseCasesRejectsMalformedLine(t *testing.T) {
	if _, err := ParseCases("not json\n"); err == nil {
		t.Fatal("ParseCases() error = nil, want an error")
	}
}

func TestParseCasesRejectsEmptyFile(t *testing.T) {
	// An exercise with no cases would silently pass everything.
	if _, err := ParseCases("\n\n"); err == nil {
		t.Fatal("ParseCases() error = nil, want an error for a caseless file")
	}
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/catalog/ -run TestParseCases -v`
Expected: FAIL — `undefined: ParseCases`, `undefined: Case`.

- [ ] **Step 3: Write the exercise types**

Create `internal/catalog/exercise.go`:

```go
package catalog

// Kind says how an exercise is built and run.
type Kind string

const (
	// KindFunction means the candidate writes a function with no main. The
	// project supplies a driver that calls it and prints the result.
	KindFunction Kind = "function"
	// KindProgram means the candidate writes a whole program, main included,
	// which is run directly on the case arguments.
	KindProgram Kind = "program"
)

// Case is one set of inputs an exercise is run against.
type Case struct {
	Args  []string `json:"args"`
	Stdin string   `json:"stdin,omitempty"`
}

// Meta is the hand-reviewed metadata stored as meta.yaml beside each exercise.
type Meta struct {
	Name             string   `yaml:"name"`
	Level            int      `yaml:"level"`
	Kind             Kind     `yaml:"kind"`
	ExpectedFile     string   `yaml:"expected_file"`
	AllowedFunctions []string `yaml:"allowed_functions"`
	Prototype        string   `yaml:"prototype"`
	Header           string   `yaml:"header,omitempty"`
	TimeoutMS        int      `yaml:"timeout_ms,omitempty"`
}

// Exercise is everything needed to present and grade one exercise.
type Exercise struct {
	Meta
	Subject       string // the upstream subject, shown to the candidate
	Spanish       string // the upstream Spanish explainer, practice mode only
	Reference     string // the oracle solution
	Driver        string // test main; empty when Kind is KindProgram
	HeaderContent string // contents of Header; empty when Header is empty
	Cases         []Case
}

// Gradable reports whether this exercise has the driver and cases needed to
// grade an answer. The importer generates every exercise's subject and
// reference solution, but drivers and cases are written by hand afterwards,
// so an exercise can legitimately exist without yet being gradable.
func (e Exercise) Gradable() bool {
	if len(e.Cases) == 0 {
		return false
	}
	return e.Kind != KindFunction || e.Driver != ""
}

// Timeout is how long one run of this exercise may take, in milliseconds.
func (e Exercise) Timeout() int {
	if e.TimeoutMS > 0 {
		return e.TimeoutMS
	}
	return 5000
}
```

- [ ] **Step 4: Write the case parser**

Create `internal/catalog/cases.go`:

```go
package catalog

import (
	"bufio"
	"encoding/json"
	"fmt"
	"strings"
)

// ParseCases reads a cases.txt file: one JSON object per line, blank lines
// ignored. JSON rather than shell-like quoting because it needs no custom
// parser and is unambiguous about an empty-string argument versus an absent
// one, a distinction several exercises depend on.
func ParseCases(text string) ([]Case, error) {
	var cases []Case
	scanner := bufio.NewScanner(strings.NewReader(text))
	for line := 1; scanner.Scan(); line++ {
		raw := strings.TrimSpace(scanner.Text())
		if raw == "" {
			continue
		}
		var c Case
		if err := json.Unmarshal([]byte(raw), &c); err != nil {
			return nil, fmt.Errorf("line %d: %w", line, err)
		}
		if c.Args == nil {
			c.Args = []string{}
		}
		cases = append(cases, c)
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("reading cases: %w", err)
	}
	if len(cases) == 0 {
		return nil, fmt.Errorf("no cases: an exercise with no cases would pass anything")
	}
	return cases, nil
}
```

- [ ] **Step 5: Run the case tests to verify they pass**

Run: `go test ./internal/catalog/ -run TestParseCases -v`
Expected: PASS.

- [ ] **Step 6: Write the failing loader test**

Create `internal/catalog/load_test.go`:

```go
package catalog

import (
	"testing"
	"testing/fstest"
)

func testFS() fstest.MapFS {
	return fstest.MapFS{
		"exercises/ft_strlen/meta.yaml": {Data: []byte(
			"name: ft_strlen\nlevel: 1\nkind: function\nexpected_file: ft_strlen.c\n" +
				"allowed_functions: []\nprototype: \"int ft_strlen(char *str);\"\n")},
		"exercises/ft_strlen/subject.md":  {Data: []byte("subject text")},
		"exercises/ft_strlen/spanish.md":  {Data: []byte("texto")},
		"exercises/ft_strlen/reference.c": {Data: []byte("int ft_strlen(char *s){return 0;}")},
		"exercises/ft_strlen/driver.c":    {Data: []byte("int main(void){return 0;}")},
		"exercises/ft_strlen/cases.txt":   {Data: []byte("{\"args\": [\"abc\"]}\n")},

		"exercises/rot_13/meta.yaml": {Data: []byte(
			"name: rot_13\nlevel: 1\nkind: program\nexpected_file: rot_13.c\n" +
				"allowed_functions: [write]\nprototype: \"\"\n")},
		"exercises/rot_13/subject.md":  {Data: []byte("subject text")},
		"exercises/rot_13/spanish.md":  {Data: []byte("texto")},
		"exercises/rot_13/reference.c": {Data: []byte("int main(void){return 0;}")},
		"exercises/rot_13/cases.txt":   {Data: []byte("{\"args\": [\"abc\"]}\n")},
	}
}

func TestLoadReadsExercises(t *testing.T) {
	c, err := Load(testFS())
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if n := len(c.All()); n != 2 {
		t.Fatalf("All() returned %d exercises, want 2", n)
	}
	ex, ok := c.ByName("ft_strlen")
	if !ok {
		t.Fatal("ByName(ft_strlen) not found")
	}
	if ex.Kind != KindFunction {
		t.Errorf("Kind = %q, want %q", ex.Kind, KindFunction)
	}
	if ex.Driver == "" {
		t.Error("Driver is empty, want the driver source")
	}
	if ex.Subject != "subject text" {
		t.Errorf("Subject = %q, want %q", ex.Subject, "subject text")
	}
	if len(ex.Cases) != 1 {
		t.Errorf("Cases = %d, want 1", len(ex.Cases))
	}
	if ex.Timeout() != 5000 {
		t.Errorf("Timeout() = %d, want the 5000 default", ex.Timeout())
	}
}

func TestLoadProgramKindNeedsNoDriver(t *testing.T) {
	c, err := Load(testFS())
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	ex, _ := c.ByName("rot_13")
	if ex.Driver != "" {
		t.Errorf("Driver = %q, want empty for a program exercise", ex.Driver)
	}
}

func TestLoadRejectsFunctionExerciseWithCasesButNoDriver(t *testing.T) {
	// Cases without a driver is a half-finished author's mistake, and must
	// not pass silently.
	fs := testFS()
	delete(fs, "exercises/ft_strlen/driver.c")
	if _, err := Load(fs); err == nil {
		t.Fatal("Load() error = nil, want an error for a function exercise with cases but no driver")
	}
}

func TestLoadAcceptsAnUnauthoredExerciseAsNonGradable(t *testing.T) {
	// The importer generates all 56 exercise directories with neither a
	// driver nor cases. Those are not yet authored, not corrupt: they must
	// load so their subjects can be read, and simply not be gradable.
	fs := testFS()
	delete(fs, "exercises/ft_strlen/driver.c")
	delete(fs, "exercises/ft_strlen/cases.txt")
	c, err := Load(fs)
	if err != nil {
		t.Fatalf("Load() error = %v, want an unauthored exercise to load", err)
	}
	ex, ok := c.ByName("ft_strlen")
	if !ok {
		t.Fatal("ByName(ft_strlen) not found")
	}
	if ex.Gradable() {
		t.Error("Gradable() = true for an exercise with no cases, want false")
	}
	if ex.Subject == "" {
		t.Error("Subject is empty; an unauthored exercise must still be readable")
	}
}

func TestGradableByLevelExcludesUnauthored(t *testing.T) {
	fs := testFS()
	delete(fs, "exercises/ft_strlen/driver.c")
	delete(fs, "exercises/ft_strlen/cases.txt")
	c, err := Load(fs)
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if n := len(c.ByLevel(1)); n != 2 {
		t.Errorf("ByLevel(1) = %d, want 2: practice lists everything", n)
	}
	got := c.GradableByLevel(1)
	if len(got) != 1 || got[0].Name != "rot_13" {
		t.Errorf("GradableByLevel(1) = %v, want only rot_13", got)
	}
}

func TestByLevelIsSortedByName(t *testing.T) {
	c, err := Load(testFS())
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	got := c.ByLevel(1)
	if len(got) != 2 {
		t.Fatalf("ByLevel(1) returned %d, want 2", len(got))
	}
	if got[0].Name != "ft_strlen" || got[1].Name != "rot_13" {
		t.Errorf("ByLevel(1) = [%s %s], want sorted [ft_strlen rot_13]", got[0].Name, got[1].Name)
	}
	if n := len(c.ByLevel(4)); n != 0 {
		t.Errorf("ByLevel(4) returned %d, want 0", n)
	}
}
```

- [ ] **Step 7: Run it to verify it fails**

Run: `go test ./internal/catalog/ -run 'TestLoad|TestByLevel' -v`
Expected: FAIL — `undefined: Load`.

- [ ] **Step 8: Write the loader**

Create `internal/catalog/load.go`:

```go
package catalog

import (
	"fmt"
	"io/fs"
	"sort"

	"gopkg.in/yaml.v3"
)

// Catalog is the set of exercises available to the application.
type Catalog struct {
	byName map[string]Exercise
	names  []string // sorted
}

// Load reads every exercise under the "exercises" directory of fsys. It is
// given an fs.FS rather than a path so the production catalog can come from
// go:embed while tests use an in-memory filesystem.
func Load(fsys fs.FS) (*Catalog, error) {
	entries, err := fs.ReadDir(fsys, "exercises")
	if err != nil {
		return nil, fmt.Errorf("reading exercises directory: %w", err)
	}
	c := &Catalog{byName: make(map[string]Exercise, len(entries))}
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		ex, err := loadExercise(fsys, "exercises/"+entry.Name())
		if err != nil {
			return nil, fmt.Errorf("exercise %s: %w", entry.Name(), err)
		}
		c.byName[ex.Name] = ex
		c.names = append(c.names, ex.Name)
	}
	if len(c.names) == 0 {
		return nil, fmt.Errorf("no exercises found")
	}
	sort.Strings(c.names)
	return c, nil
}

func loadExercise(fsys fs.FS, dir string) (Exercise, error) {
	var ex Exercise

	metaBytes, err := fs.ReadFile(fsys, dir+"/meta.yaml")
	if err != nil {
		return ex, fmt.Errorf("reading meta.yaml: %w", err)
	}
	if err := yaml.Unmarshal(metaBytes, &ex.Meta); err != nil {
		return ex, fmt.Errorf("parsing meta.yaml: %w", err)
	}
	if ex.Name == "" || ex.Level == 0 || ex.ExpectedFile == "" {
		return ex, fmt.Errorf("meta.yaml is missing name, level or expected_file")
	}
	if ex.Kind != KindFunction && ex.Kind != KindProgram {
		return ex, fmt.Errorf("meta.yaml has kind %q, want %q or %q", ex.Kind, KindFunction, KindProgram)
	}

	required := map[string]*string{
		"subject.md":  &ex.Subject,
		"reference.c": &ex.Reference,
	}
	for file, dest := range required {
		b, err := fs.ReadFile(fsys, dir+"/"+file)
		if err != nil {
			return ex, fmt.Errorf("reading %s: %w", file, err)
		}
		*dest = string(b)
	}

	// The Spanish explainer is a nicety; an exercise without one still works.
	if b, err := fs.ReadFile(fsys, dir+"/spanish.md"); err == nil {
		ex.Spanish = string(b)
	}

	// A driver is required only once cases exist; see the cases.txt handling
	// below for why an exercise may legitimately have neither yet.
	if b, err := fs.ReadFile(fsys, dir+"/driver.c"); err == nil {
		ex.Driver = string(b)
	}

	if ex.Header != "" {
		b, err := fs.ReadFile(fsys, dir+"/"+ex.Header)
		if err != nil {
			return ex, fmt.Errorf("reading declared header %s: %w", ex.Header, err)
		}
		ex.HeaderContent = string(b)
	}

	// An exercise with no cases.txt is not yet authored: the importer creates
	// every exercise's subject and reference, and drivers and cases follow by
	// hand. Such an exercise loads so its subject can be read, and reports
	// itself non-gradable. A cases.txt that exists but does not parse is a
	// real mistake and still fails.
	caseBytes, err := fs.ReadFile(fsys, dir+"/cases.txt")
	if err != nil {
		return ex, nil
	}
	if ex.Cases, err = ParseCases(string(caseBytes)); err != nil {
		return ex, fmt.Errorf("parsing cases.txt: %w", err)
	}
	if ex.Kind == KindFunction && ex.Driver == "" {
		return ex, fmt.Errorf("has cases but no driver.c, which a function exercise needs")
	}
	return ex, nil
}

// All returns every exercise, ordered by name.
func (c *Catalog) All() []Exercise {
	out := make([]Exercise, 0, len(c.names))
	for _, n := range c.names {
		out = append(out, c.byName[n])
	}
	return out
}

// ByLevel returns the exercises of one level, ordered by name. This is the
// draw pool an exam picks a single exercise from.
func (c *Catalog) ByLevel(level int) []Exercise {
	var out []Exercise
	for _, n := range c.names {
		if ex := c.byName[n]; ex.Level == level {
			out = append(out, ex)
		}
	}
	return out
}

// GradableByLevel returns the exercises of one level that can actually be
// graded. Exams draw from these: drawing an exercise that cannot be graded
// would strand the candidate on a level they have no way to clear.
func (c *Catalog) GradableByLevel(level int) []Exercise {
	var out []Exercise
	for _, ex := range c.ByLevel(level) {
		if ex.Gradable() {
			out = append(out, ex)
		}
	}
	return out
}

// ByName looks up one exercise.
func (c *Catalog) ByName(name string) (Exercise, bool) {
	ex, ok := c.byName[name]
	return ex, ok
}
```

- [ ] **Step 9: Add the yaml dependency and run the tests**

```bash
go get gopkg.in/yaml.v3@v3.0.1
go test ./internal/catalog/ -v
```
Expected: PASS, every test.

- [ ] **Step 10: Commit**

```bash
git add go.mod go.sum internal/catalog/
git commit -m "feat(catalog): exercise types and embedded loader

Load takes an fs.FS so the production catalog can come from go:embed
while tests use an in-memory filesystem. A function exercise without a
driver and a cases.txt with no cases are both load errors, since either
would let an exercise silently pass anything.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

