### Task 5: Forbidden-function detection

The check that distinguishes this trainer from running the code by hand. It catches the single most common real-exam failure: calling `printf` when the subject allows only `write`.

**Files:**
- Create: `internal/grader/symbols.go`, `internal/grader/builtins.go`
- Test: `internal/grader/symbols_test.go`

**Interfaces:**
- Consumes: nothing.
- Produces: `grader.parseNMOutput(string) []string`, `grader.normalizeSymbol(string) string`, `grader.Forbidden(undefined, allowed []string) []string`, `grader.DefinesMain([]string) bool`, `grader.objectSymbols(ctx, objPath string) (undefined, defined []string, err error)`.

- [ ] **Step 1: Write the failing unit test**

Create `internal/grader/symbols_test.go`:

```go
package grader

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"testing"
)

func TestParseNMOutput(t *testing.T) {
	// Linux nm prints bare names; macOS nm prefixes them with an underscore.
	out := "                 U memcpy\n" +
		"                 U printf\n" +
		"0000000000000000 T ft_strlen\n" +
		"                 U write\n"
	undefined, defined := parseNMOutput(out)
	wantU := []string{"memcpy", "printf", "write"}
	if !reflect.DeepEqual(undefined, wantU) {
		t.Errorf("undefined = %v, want %v", undefined, wantU)
	}
	wantD := []string{"ft_strlen"}
	if !reflect.DeepEqual(defined, wantD) {
		t.Errorf("defined = %v, want %v", defined, wantD)
	}
}

func TestParseNMOutputStripsDarwinUnderscore(t *testing.T) {
	out := "                 U _printf\n0000000000000000 T _main\n"
	undefined, defined := parseNMOutput(out)
	if !reflect.DeepEqual(undefined, []string{"printf"}) {
		t.Errorf("undefined = %v, want [printf]", undefined)
	}
	if !reflect.DeepEqual(defined, []string{"main"}) {
		t.Errorf("defined = %v, want [main]", defined)
	}
}

func TestForbiddenSubtractsAllowedAndBuiltins(t *testing.T) {
	undefined := []string{"printf", "write", "memcpy", "__stack_chk_fail"}
	got := Forbidden(undefined, []string{"write"})
	want := []string{"printf"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("Forbidden() = %v, want %v", got, want)
	}
}

func TestForbiddenWithNothingAllowed(t *testing.T) {
	got := Forbidden([]string{"write"}, nil)
	if !reflect.DeepEqual(got, []string{"write"}) {
		t.Errorf("Forbidden() = %v, want [write]", got)
	}
}

func TestForbiddenAllowsACleanObject(t *testing.T) {
	if got := Forbidden([]string{"memcpy"}, nil); len(got) != 0 {
		t.Errorf("Forbidden() = %v, want empty: memcpy is compiler-emitted", got)
	}
}

func TestDefinesMain(t *testing.T) {
	if !DefinesMain([]string{"ft_strlen", "main"}) {
		t.Error("DefinesMain() = false, want true")
	}
	if DefinesMain([]string{"ft_strlen"}) {
		t.Error("DefinesMain() = true, want false")
	}
}

// compileFixture builds a C snippet and returns the object file path.
func compileFixture(t *testing.T, src string) string {
	t.Helper()
	if _, err := exec.LookPath("cc"); err != nil {
		t.Skip("cc not available")
	}
	dir := t.TempDir()
	cPath := filepath.Join(dir, "fixture.c")
	if err := os.WriteFile(cPath, []byte(src), 0o644); err != nil {
		t.Fatal(err)
	}
	oPath := filepath.Join(dir, "fixture.o")
	cmd := exec.Command("cc", "-Wall", "-Wextra", "-Werror", "-c", cPath, "-o", oPath)
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("compiling fixture: %v\n%s", err, out)
	}
	return oPath
}

func TestObjectSymbolsFindsPrintf(t *testing.T) {
	obj := compileFixture(t, `
#include <stdio.h>
int ft_thing(void) { printf("x"); return 0; }
`)
	undefined, defined, err := objectSymbols(context.Background(), obj)
	if err != nil {
		t.Fatalf("objectSymbols() error = %v", err)
	}
	if got := Forbidden(undefined, []string{"write"}); !reflect.DeepEqual(got, []string{"printf"}) {
		t.Errorf("Forbidden() = %v, want [printf]", got)
	}
	if !contains(defined, "ft_thing") {
		t.Errorf("defined = %v, want it to contain ft_thing", defined)
	}
}

func TestObjectSymbolsToleratesCompilerEmittedMemcpy(t *testing.T) {
	// Assigning a large struct makes the compiler synthesise a memcpy the
	// candidate never wrote. Reporting that as a forbidden call would be a
	// false failure, so this must come back clean.
	obj := compileFixture(t, `
typedef struct { char buf[512]; } big_t;
big_t copy_it(big_t a) { big_t b = a; return b; }
`)
	undefined, _, err := objectSymbols(context.Background(), obj)
	if err != nil {
		t.Fatalf("objectSymbols() error = %v", err)
	}
	if got := Forbidden(undefined, nil); len(got) != 0 {
		t.Errorf("Forbidden() = %v, want empty; undefined was %v", got, undefined)
	}
}

func TestObjectSymbolsIgnoresRecursion(t *testing.T) {
	// A recursive call resolves inside the translation unit and never appears
	// as undefined, so no special case is needed for the exercise's own name.
	obj := compileFixture(t, `
int ft_list_size(void *p) { if (!p) return 0; return 1 + ft_list_size(*(void **)p); }
`)
	undefined, _, err := objectSymbols(context.Background(), obj)
	if err != nil {
		t.Fatalf("objectSymbols() error = %v", err)
	}
	if got := Forbidden(undefined, nil); len(got) != 0 {
		t.Errorf("Forbidden() = %v, want empty", got)
	}
}

func contains(list []string, s string) bool {
	for _, v := range list {
		if v == s {
			return true
		}
	}
	return false
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/grader/ -v`
Expected: FAIL — `undefined: parseNMOutput`.

- [ ] **Step 3: Write the builtin allowlist**

Create `internal/grader/builtins.go`:

```go
package grader

import "runtime"

// compilerEmitted lists symbols a compiler synthesises from code that never
// names them: memcpy and memset for aggregate assignment and large
// initialisers, the stack-protector hooks, and the runtime entry points a
// linked object refers to.
//
// Reporting one of these as a forbidden call would fail a candidate for
// something they did not write, so they are subtracted before the check. The
// lists differ by platform because clang on macOS and gcc on Linux emit
// different names.
var compilerEmitted = func() map[string]bool {
	shared := []string{
		"memcpy", "memmove", "memset", "bcopy",
		"__stack_chk_fail", "__stack_chk_guard",
	}
	platform := map[string][]string{
		"darwin": {
			"___stack_chk_fail", "___stack_chk_guard",
			"dyld_stub_binder", "__Unwind_Resume",
		},
		"linux": {
			"__stack_chk_fail_local", "_GLOBAL_OFFSET_TABLE_",
			"__gmon_start__", "_Unwind_Resume",
		},
	}
	set := make(map[string]bool)
	for _, s := range append(shared, platform[runtime.GOOS]...) {
		set[s] = true
	}
	return set
}()
```

- [ ] **Step 4: Write the symbol reader**

Create `internal/grader/symbols.go`:

```go
package grader

import (
	"context"
	"fmt"
	"os/exec"
	"runtime"
	"sort"
	"strings"
)

// objectSymbols runs nm over an object file and returns its undefined and
// defined symbol names.
func objectSymbols(ctx context.Context, objPath string) (undefined, defined []string, err error) {
	out, err := exec.CommandContext(ctx, "nm", objPath).Output()
	if err != nil {
		return nil, nil, fmt.Errorf("running nm on %s: %w", objPath, err)
	}
	undefined, defined = parseNMOutput(string(out))
	return undefined, defined, nil
}

// parseNMOutput reads nm's listing. Each line is an optional address, a
// one-letter type, and a name; type U means the symbol is undefined, so the
// object refers to it without defining it.
//
// macOS nm prefixes every C symbol with an underscore, Linux nm does not, so
// one leading underscore is stripped on darwin to make the two comparable.
func parseNMOutput(out string) (undefined, defined []string) {
	for _, line := range strings.Split(out, "\n") {
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		symType, name := fields[len(fields)-2], fields[len(fields)-1]
		if len(symType) != 1 {
			continue
		}
		name = normalizeSymbol(name)
		if symType == "U" {
			undefined = append(undefined, name)
		} else if symType == strings.ToUpper(symType) {
			// An uppercase type means a global definition; lowercase means a
			// file-local one, which no other object can call.
			defined = append(defined, name)
		}
	}
	sort.Strings(undefined)
	sort.Strings(defined)
	return dedupe(undefined), dedupe(defined)
}

// normalizeSymbol strips the leading underscore macOS adds to C symbols.
func normalizeSymbol(name string) string {
	if runtime.GOOS == "darwin" {
		return strings.TrimPrefix(name, "_")
	}
	return name
}

// Forbidden returns the undefined symbols that the subject does not allow.
//
// Nothing needs subtracting for functions the candidate defined themselves,
// including a recursive call to the exercise function: those resolve inside
// the translation unit and never appear as undefined.
func Forbidden(undefined, allowed []string) []string {
	permitted := make(map[string]bool, len(allowed))
	for _, fn := range allowed {
		permitted[fn] = true
	}
	var out []string
	for _, sym := range undefined {
		if permitted[sym] || compilerEmitted[sym] {
			continue
		}
		out = append(out, sym)
	}
	return out
}

// DefinesMain reports whether an object defines main. A function exercise
// whose file defines main would fail to link against the driver, and saying
// so plainly beats showing a duplicate-symbol linker error.
func DefinesMain(defined []string) bool {
	for _, sym := range defined {
		if sym == "main" {
			return true
		}
	}
	return false
}

func dedupe(in []string) []string {
	if len(in) == 0 {
		return nil
	}
	out := in[:1]
	for _, s := range in[1:] {
		if s != out[len(out)-1] {
			out = append(out, s)
		}
	}
	return out
}
```

- [ ] **Step 5: Run the tests to verify they pass**

Run: `go test ./internal/grader/ -v`
Expected: PASS. `TestObjectSymbolsToleratesCompilerEmittedMemcpy` is the guard against false failures; if it fails, add the symbol it names to `compilerEmitted` rather than loosening the check.

- [ ] **Step 6: Commit**

```bash
git add internal/grader/symbols.go internal/grader/builtins.go internal/grader/symbols_test.go
git commit -m "feat(grader): detect calls to functions a subject forbids

Reads undefined symbols from nm and subtracts the subject's allowed list
and a per-platform list of compiler-emitted symbols. Without that
subtraction a struct assignment synthesises memcpy and fails a candidate
for something they never wrote, which the fixture test pins down.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

