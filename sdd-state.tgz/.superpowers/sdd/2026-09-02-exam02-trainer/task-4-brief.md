### Task 4: Sandbox — running a child with a timeout

**Files:**
- Create: `internal/sandbox/run.go`
- Test: `internal/sandbox/run_test.go`

**Interfaces:**
- Consumes: nothing.
- Produces: `sandbox.Result{Stdout, Stderr string; ExitCode int; Signal string; TimedOut bool}` and `sandbox.Run(ctx context.Context, bin string, args []string, stdin string, timeout time.Duration) (Result, error)`.

- [ ] **Step 1: Write the failing test**

Create `internal/sandbox/run_test.go`:

```go
package sandbox

import (
	"context"
	"strings"
	"testing"
	"time"
)

func TestRunCapturesStdout(t *testing.T) {
	got, err := Run(context.Background(), "/bin/echo", []string{"hello"}, "", time.Second)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if got.Stdout != "hello\n" {
		t.Errorf("Stdout = %q, want %q", got.Stdout, "hello\n")
	}
	if got.ExitCode != 0 {
		t.Errorf("ExitCode = %d, want 0", got.ExitCode)
	}
	if got.TimedOut {
		t.Error("TimedOut = true, want false")
	}
}

func TestRunCapturesExitCode(t *testing.T) {
	got, err := Run(context.Background(), "/bin/sh", []string{"-c", "exit 3"}, "", time.Second)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if got.ExitCode != 3 {
		t.Errorf("ExitCode = %d, want 3", got.ExitCode)
	}
}

func TestRunFeedsStdin(t *testing.T) {
	got, err := Run(context.Background(), "/bin/cat", nil, "piped\n", time.Second)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if got.Stdout != "piped\n" {
		t.Errorf("Stdout = %q, want %q", got.Stdout, "piped\n")
	}
}

func TestRunReportsSignal(t *testing.T) {
	got, err := Run(context.Background(), "/bin/sh", []string{"-c", "kill -SEGV $$"}, "", time.Second)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if got.Signal != "SIGSEGV" {
		t.Errorf("Signal = %q, want %q", got.Signal, "SIGSEGV")
	}
}

func TestRunTimesOut(t *testing.T) {
	start := time.Now()
	got, err := Run(context.Background(), "/bin/sh", []string{"-c", "sleep 30"}, "", 200*time.Millisecond)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if !got.TimedOut {
		t.Error("TimedOut = false, want true")
	}
	if elapsed := time.Since(start); elapsed > 5*time.Second {
		t.Errorf("Run() took %v, want it to give up promptly", elapsed)
	}
}

func TestRunTimeoutKillsGrandchildren(t *testing.T) {
	// A child that backgrounds work must not outlive the timeout. If the
	// process group is not killed, this Run blocks until the grandchild's
	// sleep finishes, well past the deadline.
	start := time.Now()
	got, err := Run(context.Background(), "/bin/sh",
		[]string{"-c", "sleep 30 & wait"}, "", 200*time.Millisecond)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if !got.TimedOut {
		t.Error("TimedOut = false, want true")
	}
	if elapsed := time.Since(start); elapsed > 5*time.Second {
		t.Errorf("Run() took %v; the grandchild was not killed", elapsed)
	}
}

func TestRunMissingBinaryIsAnError(t *testing.T) {
	_, err := Run(context.Background(), "/nonexistent/binary", nil, "", time.Second)
	if err == nil {
		t.Fatal("Run() error = nil, want an error")
	}
	if !strings.Contains(err.Error(), "binary") {
		t.Logf("error was %v", err) // message content is not contractual
	}
}
```

- [ ] **Step 2: Run it to verify it fails**

Run: `go test ./internal/sandbox/ -v`
Expected: FAIL — `undefined: Run`.

- [ ] **Step 3: Write the implementation**

Create `internal/sandbox/run.go`:

```go
// Package sandbox runs candidate binaries under a time limit.
//
// The timeout is enforced here in Go rather than by shelling out to
// timeout(1), which macOS does not ship.
package sandbox

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os/exec"
	"strings"
	"syscall"
	"time"
)

// Result is the observable outcome of one run.
type Result struct {
	Stdout   string
	Stderr   string
	ExitCode int
	Signal   string // e.g. "SIGSEGV"; empty when the process exited normally
	TimedOut bool
}

// Run executes bin with args, feeding it stdin, and gives up after timeout.
//
// The child is put in its own process group so that on timeout the whole
// group can be killed: a candidate program that forks must not leave work
// running after its attempt is over.
//
// A non-nil error means the run could not be performed at all. A program that
// crashes or is killed is a successful Run with that outcome recorded in the
// Result.
func Run(ctx context.Context, bin string, args []string, stdin string, timeout time.Duration) (Result, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	cmd := exec.Command(bin, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Stdin = strings.NewReader(stdin)

	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Start(); err != nil {
		return Result{}, fmt.Errorf("starting binary %s: %w", bin, err)
	}

	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()

	var result Result
	select {
	case err := <-done:
		result = describe(err)
	case <-ctx.Done():
		// Negating the pid addresses the whole process group.
		_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
		<-done
		result = Result{TimedOut: true, ExitCode: -1}
	}

	result.Stdout = stdout.String()
	result.Stderr = stderr.String()
	return result, nil
}

// describe turns the error from cmd.Wait into an exit code and signal name.
func describe(err error) Result {
	if err == nil {
		return Result{ExitCode: 0}
	}
	var exitErr *exec.ExitError
	if !errors.As(err, &exitErr) {
		return Result{ExitCode: -1}
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok {
		return Result{ExitCode: exitErr.ExitCode()}
	}
	if status.Signaled() {
		return Result{ExitCode: -1, Signal: signalName(status.Signal())}
	}
	return Result{ExitCode: status.ExitStatus()}
}

// signalName renders a signal the way a candidate would recognise it.
func signalName(sig syscall.Signal) string {
	switch sig {
	case syscall.SIGSEGV:
		return "SIGSEGV"
	case syscall.SIGABRT:
		return "SIGABRT"
	case syscall.SIGBUS:
		return "SIGBUS"
	case syscall.SIGFPE:
		return "SIGFPE"
	case syscall.SIGKILL:
		return "SIGKILL"
	default:
		return sig.String()
	}
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `go test ./internal/sandbox/ -v`
Expected: PASS, all seven tests. `TestRunTimeoutKillsGrandchildren` completing in well under a second is the one that proves the process-group kill works.

- [ ] **Step 5: Commit**

```bash
git add internal/sandbox/
git commit -m "feat(sandbox): run candidate binaries under a time limit

Timeout is enforced in Go because macOS ships no timeout(1). The child
runs in its own process group so a program that forks cannot leave work
running past its deadline; the grandchild test is what proves it.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

